/**
 * -------------------------
 * Student Name:george fotabong
 * Student ID: 200484320
 * Student email: fota4320@mylaurier.ca
 * -------------------------
 */

/**
 * ------------------------------------------
 * Graph (implementation file)
 * Implementation: 	Adjacency matrix
 * Directed:		No
 * Weighted:		No
 * Loops?			No
 * ------------------------------------------
 */

# include <stdio.h>
# include <stdlib.h>
# include <string.h>
# include <assert.h>
# include "graph.h"

void _expand_graph(Graph *g);
int _remove_edges(Graph *g, Vertex *v);
void _copy_column(int **array, const int size, int source, int destination);
void _copy_row(int **array, const int size, int source, int destination);

//------------------- Vertex -----------------------
/**
 * --------------------------------------------------------------
 * Parameters: 	label- a vertex label/name (char*)
 * Returns: 	A vertex pointer (Vertex*)
 * Description:	Creates a vertex
 * 				Uses dynamic memory allocation to create a vertex pointer
 * 				uvid is set using a static counter starting at 1
 * 				gvid is set by default to -1 indicating not added to graph
 * 				If label is empty string, use: "V<uvid>"
 * --------------------------------------------------------------
 */
Vertex* create_vertex(char *label) {
	Vertex *v = (Vertex*) malloc(sizeof(Vertex));

	static int uvid = 1;
	v->uvid = uvid++;
	v->gvid = -1;
	if (strcmp(label, "") == 0)
		sprintf(v->label, "%d", v->uvid);
	else
		strcpy(v->label, label);
	return v;
}

/**
 * ------------------------------------------------------------
 * Parameters: 	A vertex pointer (Vertex*)
 * Returns: 	none
 * Description:	prints a given vertex as: (<gvid>,<label>)
 * Asserts:		vertex pointer is not null
 * ------------------------------------------------------------
 */
void print_vertex(Vertex *v) {
	assert(v);
	printf("(%d,%s)", v->gvid, v->label);

	return;
}

/**
 * -----------------------------------------------------
 * Parameters: 	A vertex double pointer (Vertex**)
 * Returns: 	none
 * Description:	destroys a vertex
 * 				1- sets vertex uvid and gvid to 0
 * 				2- sets vertex label to an empty string
 * 				3- deallocates vertex pointer and set it to NULL
 * Asserts:		v and *v are not null
 * ------------------------------------------------------
 */
void destroy_vertex(Vertex **v) {
	assert(v && *v);
	(*v)->uvid = 0;
	(*v)->gvid = 0;
	strcpy((*v)->label, "");
	free(*v);
	(*v) = NULL;

	return;
}

//--------------------- Edge -----------------------------
/**
 * -----------------------------------------------------------------
 * Parameters: 	v1 - first (source) vertex (Vertex*)
 * 				v2 - second (destination) vertex (Vertex*)
 * Returns: 	An edge pointer (Edge*)
 * Description:	Creates an edge using given parameters
 * 				allocates memory to an edge pointer
 * 				sets the two vertices, weight and directed flag to given parameters.
 * Asserts:		given two vertices are not NULL
 * ------------------------------------------------------------------
 */
Edge* create_edge(Vertex *v1, Vertex *v2) {
	assert(v1 && v2);
	Edge *e = (Edge*) malloc(sizeof(Edge));
	e->v1 = v1;
	e->v2 = v2;

	return e;
}

/**
 * --------------------------------------------------------------------
 * Parameters: 	An edge double pointer (Edge**)
 * Returns: 	none
 * Description:	destroys an edge
 * 				Deallocates the edge pointer
 * 				Note: since the vertices may be shared by other edges -->
 * 				the function should not destroy the vertices
 * Asserts 		e and *e are not null
 * --------------------------------------------------------------------
 */
void destroy_edge(Edge **e) {
	assert(e && *e);
	(*e)->v1 = NULL;
	(*e)->v2 = NULL;
	free(*e);
	*e = NULL;
	return;
}

/**
 * -----------------------------------------------------------
 * Parameters: 	An edge pointer (Edge*)
 * Returns: 	none
 * Description:	prints an edge
 * 				format: "[<v1>-----<v2>]"
 * Asserts:		edge pointer is not null
 * -----------------------------------------------------------
 */
void print_edge(Edge *e) {
	assert(e);
	printf("[");
	print_vertex(e->v1);
	printf("------");
	print_vertex(e->v2);
	printf("]");
	return;
}

/**
 * ---------------------------------------------------------------------------
 * Parameters: 	e1 - First edge (Edge*)
 * 				e2 - Second edge (Edge*)
 * Returns: 	True/False
 * Description:	checks if two edges are equal
 * 				Equality is established if the two vertices are equal
 * 				Vertices are compared based on their uvid
 * 				returns True (1) if equal, and False (0) if unequal
 * 				Note: v1--v2 is equal to v2--v1
 * Asserts:		e1 and e2 pointers are not null
 * ----------------------------------------------------------------------------
 */
int is_equal_edge(Edge *e1, Edge *e2) {
	assert(e1 && e2);
	int result = False;
	if (e1->v1->uvid == e2->v1->uvid && e1->v2->uvid == e2->v2->uvid)
		result = True;
	else if (e1->v2->uvid == e2->v1->uvid && e1->v1->uvid == e2->v2->uvid)
		result = True;
	return result;
}

//--------------------- Graph -----------------------------

/**
 * -----------------------------------------------------------------
 * Parameters: 	none
 * Returns: 	A graph pointer (Graph*)
 * Description:	Creates a null graph (no edges, no vertices)
 * 				1- Allocate memory for graph structure
 * 				2- Creates an empty adjacency matrix BLOCK x BLOCK,
 * 				3- Initialize all cells in the AM to 0
 * 				4- Set vertex and edge counters to 0
 * 				5- Create an array of vertex pointers and initialize all elements to NULL
 * -----------------------------------------------------------------
 */
Graph* create_graph() {
	int i, j;
	//1- create graph pointer
	Graph *g = (Graph*) malloc(sizeof(Graph));

	//2- create adj matrix
	g->matrix = (int**) malloc(sizeof(int) * BLOCK);
	for (i = 0; i < BLOCK; i++)
		g->matrix[i] = (int*) malloc(sizeof(int) * BLOCK);
	//3-initilaize all elements in AM = 0
	for (i = 0; i < BLOCK; i++)
		for (j = 0; j < BLOCK; j++)
			g->matrix[i][j] = 0;

	//4 set cnts to 0
	g->edge_count = 0;
	g->vertex_count = 0;

	//5 create array of vertex pointers and initilaize to NULL
	g->vertices = (Vertex**) malloc(sizeof(Vertex*) * BLOCK);
	for (i = 0; i < BLOCK; i++)
		g->vertices[i] = NULL;

	//set memory size to block
	g->_memory_size = BLOCK;

	return g;
}

/**
 * ----------------------------------------------------------------------
 * Parameters: 	g: A graph double pointer (Graph**)
 * Returns: 	none
 * Description:	destroys a graph through:
 * 				1- free memory allocated to the adjacency matrix, set pointer to NULL
 * 				2- Free memory allocated to vertex list
 * 				3- Reset edge and vertex count and all flags to 0
 * 				4- free memory allocated to graph, set pointer to NULL
 * Asserts:		g and *g are not null
 * -----------------------------------------------------------------------
 */
void destroy_graph(Graph **g) {
	assert(g && *g);

	//1- free all rows in the AM
	for (int i = 0; i < (*g)->_memory_size; i++) {
		free((*g)->matrix[i]);
		(*g)->matrix[i] = NULL;
	}

	//free matrix
	free((*g)->matrix);
	(*g)->matrix = NULL;

	//2 fre vertex list
	free((*g)->vertices);
	(*g)->vertices = NULL;

	//3 set vertex and edge cnt to 0
	(*g)->vertex_count = 0;
	(*g)->edge_count = 0;
	(*g)->_memory_size = 0;

	//4 free memory allocated to graph
	free(*g);
	*g = NULL;
	return;
}

/**
 * --------------------------------------------------------------
 * Parameters: 	A graph pointer (Graph*)
 * Returns: 	True/False
 * Description:	Checks if a given graph is a null graph
 * 				A null graph is a graph with no vertices (which also means no edges)
 * 				return True if null graph and False otherwise
 * Asserts:		Graph pointer is not NULL
 * ---------------------------------------------------------------
 */
int is_null_graph(Graph *g) {
	//your code here
	assert(g);

	return (g->vertex_count == 0);
}

/**
 * -----------------------------------------------------------
 * Parameters: 	A graph pointer (Graph*)
 * Returns: 	True/False
 * Description:	Checks if a given graph is an empty graph
 * 				An empty graph is a graph with no edges
 * 				return True if empty graph and False otherwise
 * Asserts:		Graph pointer is not NULL
 * -----------------------------------------------------------
 */
int is_empty_graph(Graph *g) {
	//your code here
	assert(g);

	return (g->edge_count == 0);
}

/**
 * ------------------------------------------------------------------------
 * Parameters: 	A graph pointer (Graph*)
 * Returns: 	none
 * Description:	Prints the contents of a given graph
 * 				1- if null graph, prints: "<"null graph>\n", otherwise:
 * 				2- graph meta-data in the following format:
 * 					"(<representation>): #Vertices = <num>, #edges = <num>\n"
 * 				3- Prints adjacency matrix in tabular format
 * 				Asserts given graph is not NULL
 * 	Analysis:	Printing a graph is O(V^2)
 * 				because adjacency matrix has O(V^2) memory blocks
 * -------------------------------------------------------------------------
 */
void print_graph(Graph *g) {
	assert(g);
	int i, j;
	printf("Graph: [Adjacency Matrix][undirected][non-weighted][no loops]:\n");
	printf("#Vertices = %d, #Edges = %d, memory_size = %d\n", g->vertex_count,
			g->edge_count, g->_memory_size);
	if (is_null_graph(g)) {
		printf("<null graph>\n");
		return;
	}

	//print all vertices, each BLOCK on a separate line
	printf("Vertices:\n");
	for (i = 0; i < g->vertex_count; i++) {
		print_vertex(g->vertices[i]);
		if ((i + 1) % BLOCK == 0 || i == g->vertex_count - 1)
			printf("\n");
		else
			printf(" , ");
	}

	//print AM as a 2D matrix.
	if (g->vertex_count == 1)
		printf("%5s\n", "-");
	else {
		for (i = 0; i < g->vertex_count; i++) {
			for (j = 0; j < g->vertex_count; j++) {
				if (g->matrix[i][j] == 0)
					printf("%5s ", "-");
				else
					printf("%5d ", g->matrix[i][j]);
			}
			printf("\n");
		}
	}

	return;
}

/**
 * ---------------------------------------------------------------------------
 * Parameters: 	A graph pointer (Graph*)
 * 				A vertex pointer (Vertex*)
 * Returns: 	True/False
 * Description:	Checks if a given graph contains the given vertex
 * 				Search through g->vertices comparing g->uvid
 * Asserts:		Graph and vertex pointers are not NULL
 * Analysis:	0(n)------> 0(log(n)), 0(1)
 * ----------------------------------------------------------------------------
 */
int has_vertex_graph(Graph *g, Vertex *v) {
	//your code here
	assert(g && v);
	for (int i = 0; i < g->vertex_count; i++)
		if (g->vertices[i]->uvid == v->uvid)
			return True;
	return False;
}

/**
 * ---------------------------------------------------------------------------
 * Parameters: 	A graph pointer (Graph*)
 * 				A vertex pointer (Vertex*)
 * Returns: 	success (True/False)
 * Description:	Adds a vertex to a graph
 * 				Performs the following:
 * 				1- if vertex already exist --> error, return False
 * 				2- Set the vertex gvid to a new sequential value
 * 				3- Add vertex to vertices array and increment vertex count
 * 				4- If AM is full, expand the memory
 * Asserts:		Asserts given graph and vertex are not NULL pointers
 * Analysis:	?
 * ----------------------------------------------------------------------------
 */
int add_vertex_graph(Graph *g, Vertex *v) {
	//your code here
	assert(g && v);
	//1- should not duplicate verticies
	if (has_vertex_graph(g, v)) {
		printf("Error");
		return False;
	}

	//1 get gvid of vertex
	v->gvid = g->vertex_count;

	//3 add vertex  to vertex list and increment vertex count
	g->vertices[g->vertex_count++] = v;

	//4- if AM is full expand memory
	if (g->vertex_count == g->_memory_size)
		_expand_graph(g);
	return False;
}
//--------------------- Private Utility Functions -----------------------------

/**
 * ----------------------------------------------------------------
 * Private Utility Function
 * Parameters: 	A graph pointer (Graph*)
 * Returns: 	no returns
 * Description:	Expands the graph by adding a BLOCK size of memory
 * Asserts:		Graph pointer is not NULL
 * ---------------------------------------------------------------
 */
void _expand_graph(Graph *g) {
	assert(g);
	int i, j;
	int new_size = g->_memory_size + BLOCK;

	//expand the verticies array
	g->vertices = (Vertex**) realloc(g->vertices, sizeof(Vertex*) * new_size);
	//initialize new slots to NULL
	for (i = g->vertex_count; i < new_size; i++)
		g->vertices[i] = NULL;
	//resize the AM
	g->matrix = (int**) realloc(g->matrix, sizeof(int*) * new_size);

	//resize exsiting rows byh addiing collumns
	for (i = 0; i < g->vertex_count; i++)
		g->matrix[i] = (int*) realloc(g->matrix[i], sizeof(int) * new_size);
	//initialize the new cells to 0
	for (i = 0; i < g->vertex_count; i++)
		for (j = g->vertex_count; j < new_size; j++)
			g->matrix[i][j] = 0;
	//add new rows
	for (i = g->vertex_count; i < new_size; i++)
		g->matrix[i] = (int*) malloc(sizeof(int) * new_size);
	//initilaixze new rows
	for (i = g->vertex_count; i < new_size; i++)
		for (j = 0; j < new_size; j++)
			g->matrix[i][j] = 0;
	//update memory size
	g->_memory_size = new_size;

	return;
}
/**
 * ---------------------------------------------------------------------------
 * Parameters: 	A graph pointer (Graph*)
 * 				A vertex pointer (Vertex*)
 * Returns: 	success (True/False)
 * Description:	Removes a vertex to a graph
 * 				Performs the following:
 * 				1- if vertex does not exist --> error, return False
 * 				2- Remove all edges associated with the vertex
 * 				3- Update AM by replacing vertex with the last vertex, update gvid accordingly
 * 				4- Update edge and vertex counts
 * Asserts:		Asserts given graph and vertex are not NULL pointers
 * Analysis:	?
 * ----------------------------------------------------------------------------
 */
int remove_vertex_graph(Graph *g, Vertex *v) {
	//your code here
	assert(g && v);
	//1 check if vertex exisit
	if (v->gvid == -1 || v->gvid >= g->vertex_count) {
		printf("error");
		return False;
	}
	//remove all edges  ass with vert and updat edge count
	g->edge_count -= _remove_edges(g, v) / 2;

	//update gvids of verticies
	int indx = v->gvid;
	int last_vertex = (indx == g->vertex_count - 1) ? 1 : 0;
	g->vertices[g->vertex_count - 1]->gvid = indx;
	g->vertices[indx]->gvid = -1; //set

	//replace vertex with last vertex
	if (!last_vertex) {
		_copy_column(g->matrix, g->vertex_count, g->vertex_count - 1, indx);
		_copy_row(g->matrix, g->vertex_count, g->vertex_count - 1, indx);

	}
	//remove vertex list copy last vertex to removed vertex update vertrex
	if (!last_vertex)
		g->vertices[indx] = g->vertices[g->vertex_count - 1];
	g->vertices[g->vertex_count - 1] = NULL;
	g->vertex_count--;
	return False;
}

/**
 * -------------------------------------------------------------------
 * Parameters: 	A graph pointer (Graph*)
 * 				An edge pointer (Edge*)
 * Returns: 	True/False
 * Description:	Checks if a given graph contains the given edge
 * 				Need to verify:
 * 				1- Graph is not empty/null
 * 				2- Graph contains both vertices of the given edge
 * 				3- Edge is undirected
 * 				In order to return True:
 * 				If weighted graph, matrix[v1][v2] should be equivalent to given weight
 * 				If non-weighted graph, matrix[v1][v2] should be 1
 * 				Asserts given graph and edge are not NULL pointers
 * Analysis:	?
 * -------------------------------------------------------------------
 */
int has_edge_graph(Graph *g, Edge *e) {
	//your code here
	assert(g && e);
	//
	if (is_empty_graph(g))
		return False;
	if (e->v1->gvid >= g->vertex_count || e->v1->gvid == -1)
		return False;

	if (e->v2->gvid >= g->vertex_count || e->v2->gvid == -1)
		return False;
	if (g->matrix[e->v1->gvid][e->v2->gvid] == 1)
		return True;
	return False;
}

/**
 * ---------------------------------------------------------------------------------
 * Parameters: 	A graph pointer (Graph*)
 * 				An edge pointer (Edge*)
 * Returns: 	success (True/False)
 * Description:	Adds an edge to a graph
 * 				Performs the following:
 * 				1- if edge already exist --> error, return False
 * 				2- If any of the vertices does not exist in the graph --> add it
 * 				3- Adds edge to the matrix by setting right cells in AM
 * 				4- Increments the edge count
 * Asserts:		Given graph and edge are not NULL pointers
 * Analysis:	?
 * --------------------------------------------------------------------------------
 */
int add_edge_graph(Graph *g, Edge *e) {
	//your code here
	assert(g && e);
	if (has_edge_graph(g, e)) {
		printf("errpr");
		return False;
	}
	if (!has_vertex_graph(g, e->v1))
		add_vertex_graph(g, e->v1);
	if (!has_vertex_graph(g, e->v2))
		add_vertex_graph(g, e->v2);

	g->matrix[e->v1->gvid][e->v2->gvid] = 1;
	g->matrix[e->v2->gvid][e->v1->gvid] = 1;

	g->edge_count++;

	return False;
}

/**
 * ----------------------------------------------------------------
 * Parameters: 	A graph pointer (Graph*)
 * 				An edge pointer (Edge*)
 * Returns: 	success: (True/False)
 * Description:	removes a given edge from graph
 * 				1- if the edge does not exist --> error, return False
 * 				2- Set the corresponding AM cells to 0
 * 				3- decrement the edge count
 * Asserts:		Graph and Edge are not NULL pointers
 * Analysis:	?
 * ---------------------------------------------------------------
 */
int remove_edge_graph(Graph *g, Edge *e) {
	//your code here
	assert(g && e);
	if (is_empty_graph(g) || !has_edge_graph(g, e)) {
		printf("error");
		return False;
	}

	g->matrix[e->v1->gvid][e->v2->gvid] = 0;
	g->matrix[e->v2->gvid][e->v1->gvid] = 0;

	g->edge_count--;

	return False;
}

/**
 * --------------------------------------------------------------
 * Private Utility Function
 * Parameters: 	A graph pointer (Graph*)
 * 				A Vertex pointer (Vertex*)
 * Returns: 	number of removed edges (int)
 * Description:	Removes all edges associated with a specific vertex
 * 				Sets the relevant cells in the adjacency matrix to 0
 * 				Assumes graph has the vertex
 * Asserts:		Graph and Vertex pointers are not NULL
 * Analysis:	?
 * ---------------------------------------------------------------
 */
int _remove_edges(Graph *g, Vertex *v) {
	//your code here
	assert(g && v);
	int i, j, edge_counter = 0;
	for (i = 0; i < g->vertex_count; i++)
		if (g->matrix[i][v->gvid] == 1) {
			g->matrix[i][v->gvid] = 0;
			edge_counter++;
		}
	for (j = 0; j < g->vertex_count; j++)
		if (g->matrix[v->gvid][j] == 1) {
			g->matrix[v->gvid][j] = 0;
			edge_counter++;
		}
	return edge_counter;
}

/**
 * --------------------------------------------------------------
 * Private Utility Function
 * Parameters:     array: a 2D integer array (int**)
 *                 size: size of array (int)
 *                 source: index of source column
 *                 destination: index of destination column
 * Returns:     no returns
 * Description:    copy column (source) into column (destination) in array
 *                 if invalid indices, no operation is done
 * Asserts:        array and *array and not NULL
 * Analysis:    O(n)
 * ---------------------------------------------------------------
 */
void _copy_column(int **array, const int size, int source, int destination) {
	assert(array && *array);
	//error cases
	if (size <= 0 || source < 0 || source > size - 1 || destination < 0
			|| destination > size - 1)
		return;
	//do nothing
	if (source == destination)
		return;
	for (int i = 0; i < size; i++)
		array[i][destination] = array[i][source];
	return;
}

/**
 * --------------------------------------------------------------
 * Private Utility Function
 * Parameters:     array: a 2D integer array (int**)
 *                 size: size of array (int)
 *                 source: index of source row
 *                 destination: index of destination row
 * Returns:     no returns
 * Description:    copy row (source) into row (destination) in array
 *                 if invalid indices, no operation is done
 * Asserts:        array and *array and not NULL
 * Analysis:    O(n)
 * ---------------------------------------------------------------
 */
void _copy_row(int **array, const int size, int source, int destination) {
	assert(array && *array);
	//error cases
	if (size <= 0 || source < 0 || source > size - 1 || destination < 0
			|| destination > size - 1)
		return;
	//do nothing
	if (source == destination)
		return;
	for (int i = 0; i < size; i++)
		array[destination][i] = array[source][i];
	return;
}
