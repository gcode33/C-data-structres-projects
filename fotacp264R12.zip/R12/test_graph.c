/**
 * ------------------------------------------
 * Graph (Testing file)
 * Implementation: 	Adjacency matrix
 * Directed:		No
 * Weighted:		No
 * Loops?			No
 * ------------------------------------------
 */

# include <stdio.h>
# include <stdlib.h>
# include <string.h>
# include "graph.h"

void test_vertex();
void test_edge();
void test_basic_graph();
void test_vertex_graph();
void test_edge_graph();
void test_remove_vertex();

int main() {
	setbuf(stdout, NULL);
	test_vertex();
	test_edge();
	test_basic_graph();
	test_vertex_graph();
	test_edge_graph();
	test_remove_vertex();
	return 0;
}

void test_vertex() {
	printf("------------------------------\n");
	printf("Start: Testing Vertex Struct:\n\n");

	char cities[4][20] = { "Toronto", "Ottawa", "Waterloo", "" };
	Vertex *v[4];
	int i;

	//initialize vertex pointers to NULL
	for (i = 0; i < 4; i++)
		v[i] = NULL;

	printf("Creating Vertices:\n");
	for (i = 0; i < 4; i++) {
		v[i] = create_vertex(cities[i]);
		print_vertex(v[i]);
		printf("\n");
	}
	printf("\n");

	for (i = 0; i < 4; i++)
		destroy_vertex(&v[i]);
	printf("vertices were successfully destroyed\n\n");

	printf("End: Testing Vertex Struct\n");
	printf("------------------------------\n\n");
	return;
}

void test_edge() {
	printf("------------------------------\n");
	printf("Start: Testing Edge Struct:\n\n");

	char cities[4][20] = { "Toronto", "Ottawa", "Waterloo", "London" };
	Vertex *v[4];
	int i;

	//initialize vertex pointers to NULL
	for (i = 0; i < 4; i++)
		v[i] = NULL;

	printf("List of Vertices:\n");
	for (i = 0; i < 4; i++) {
		v[i] = create_vertex(cities[i]);
		print_vertex(v[i]);
		printf(" ");
	}
	printf("\n\n");

	Edge *e[5];
	for (i = 0; i < 5; i++)
		e[i] = NULL;

	int first[5] = { 2, 0, 1, 1, 3 };
	int second[5] = { 3, 3, 0, 3, 0 };
	for (i = 0; i < 5; i++) {
		e[i] = create_edge(v[first[i]], v[second[i]]);
		print_edge(e[i]);
		printf("\n");
	}
	printf("\n");

	print_edge(e[2]);
	printf(" == ");
	print_edge(e[4]);
	printf("? %d\n", is_equal_edge(e[2], e[4]));
	print_edge(e[2]);
	printf(" == ");
	print_edge(e[2]);
	printf("? %d\n", is_equal_edge(e[2], e[2]));
	print_edge(e[4]);
	printf(" == ");
	print_edge(e[1]);
	printf("? %d\n", is_equal_edge(e[4], e[1]));
	printf("\n");

	for (i = 0; i < 5; i++)
		destroy_edge(&e[i]);
	printf("edges were successfully destroyed\n");

	for (i = 0; i < 4; i++)
		destroy_vertex(&v[i]);
	printf("vertices were successfully destroyed\n\n");

	printf("End: Testing Edge Struct\n");
	printf("------------------------------\n\n");
	return;
}

void test_basic_graph() {
	printf("------------------------------\n");
	printf("Start: Testing Graph Basic Functions:\n\n");

	printf("Graph* g = create_graph();\n");
	Graph *g = create_graph();
	printf("graph created successfully\n");
	printf("\n");

	printf("invoke print_graph(g)\n");
	print_graph(g);
	printf("\n");

	printf("is_null? = %d\n", is_null_graph(g));
	printf("is_empty? = %d\n", is_empty_graph(g));
	printf("\n");

	printf("vertex count = %d\n", g->vertex_count);
	printf("edge count = %d\n", g->edge_count);
	printf("\n");

	destroy_graph(&g);
	printf("graph destroyed successfully\n");
	printf("\n");

	printf("End: Testing Graph Basic functions\n");
	printf("------------------------------\n\n");
	return;
}

void test_vertex_graph() {
	printf("------------------------------\n");
	printf("Start: Testing Graph with vertices:\n\n");

	printf("Creating a null graph\n");
	Graph *g = create_graph();
	print_graph(g);
	printf("\n");

	Vertex *v[11];
	int i;
	for (i = 0; i < 11; i++) {
		v[i] = create_vertex("");
		printf("Adding Vertex:");
		print_vertex(v[i]);
		printf("\n");
		printf("add_vertex_graph successful? = %d\n",
				add_vertex_graph(g, v[i]));
		print_graph(g);
		printf("\n");
	}

	printf("Adding a duplicate Vertex:");
	print_vertex(v[--i]);
	printf("\n");
	printf("add_vertex_graph successful? = %d\n", add_vertex_graph(g, v[i]));
	print_graph(g);
	printf("\n");

	for (i = 0; i < 11; i++)
		destroy_vertex(&v[i]);
	printf("Vertices destroyed successfully\n");
	destroy_graph(&g);
	printf("Graph destroyed successfully\n\n");

	printf("End: Testing Graph with vertices\n");
	printf("------------------------------\n\n");
	return;
}

void test_edge_graph() {
	printf("------------------------------\n");
	printf("Start: Testing Graph with Edges:\n\n");

	printf("Creating a graph with 8 vertices\n");
	Graph *g = create_graph();

	int i;
	Vertex *v[8];
	for (i = 0; i < 8; i++) {
		v[i] = create_vertex("");
		add_vertex_graph(g, v[i]);
	}

	print_graph(g);
	printf("\n");

	Edge *e[11];

	printf("Adding an edge between %s and %s\n", v[0]->label, v[1]->label);
	e[0] = create_edge(v[0], v[1]);
	add_edge_graph(g, e[0]);
	print_graph(g);
	printf("\n");

	printf("is_null? = %d\n", is_null_graph(g));
	printf("is_empty? = %d\n", is_empty_graph(g));
	printf("\n");

	int first[6] = { 4, 1, 0, 1, 3, 2 };
	int second[6] = { 5, 4, 4, 5, 4, 6 };
	for (i = 0; i < 6; i++) {
		printf("Adding an edge between %s and %s\n", v[first[i]]->label,
				v[second[i]]->label);
		e[i + 1] = create_edge(v[first[i]], v[second[i]]);
		add_edge_graph(g, e[i + 1]);
		print_graph(g);
		printf("\n");

	}

	printf("Error case:\n");
	add_edge_graph(g, e[3]);
	printf("\n");

	printf("Adding three more edges\n");
	e[8] = create_edge(v[2], v[4]);
	add_edge_graph(g, e[8]);
	e[9] = create_edge(v[0], v[7]);
	add_edge_graph(g, e[9]);
	e[10] = create_edge(v[4], v[6]);
	add_edge_graph(g, e[10]);
	print_graph(g);
	printf("\n");

	int e_indx[4] = { 5, 3, 9, 0 };
	for (i = 0; i < 4; i++) {
		printf("Removing edge: ");
		print_edge(e[e_indx[i]]);
		printf("\n");
		remove_edge_graph(g, e[e_indx[i]]);
		print_graph(g);
		printf("\n");
	}

	for (i = 0; i < 11; i++)
		destroy_edge(&e[i]);
	printf("Edges destroyed successfully\n");
	for (i = 0; i < 8; i++)
		destroy_vertex(&v[i]);
	printf("Vertices destroyed successfully\n");
	destroy_graph(&g);
	printf("Graph destroyed successfully\n\n");

	printf("End: Testing Graph with edges\n");
	printf("------------------------------\n\n");
	return;
}

void test_remove_vertex() {
	printf("------------------------------\n");
	printf("Start: Testing remove_vertex_graph:\n\n");

	printf("Creating a graph with 8 vertices\n");
	Graph *g = create_graph();
	int i;

	Vertex *v[8];
	for (i = 0; i < 8; i++) {
		v[i] = create_vertex("");
		add_vertex_graph(g, v[i]);
	}
	printf("\n");
	print_graph(g);
	printf("\n");

	Edge *e[12];
	int first[12] = { 0, 4, 1, 0, 1, 3, 2, 6, 3, 2, 0, 4 };
	int second[12] = { 1, 5, 4, 4, 5, 4, 6, 4, 6, 7, 7, 7 };
	printf("Adding 12 edges:\n");
	for (i = 0; i < 12; i++) {
		printf("Adding an edge between %s and %s\n", v[first[i]]->label,
				v[second[i]]->label);
		e[i] = create_edge(v[first[i]], v[second[i]]);
		add_edge_graph(g, e[i]);
	}
	printf("\n");
	print_graph(g);
	printf("\n");

	int rv[9] = { 3, 2, 0, 4, 7, 5, 6, 1, 0 };
	for (i = 0; i < 9; i++) {
		printf("remove vertex: %s:\n", v[rv[i]]->label);
		remove_vertex_graph(g, v[rv[i]]);
		print_graph(g);
		printf("\n");
	}

	for (i = 0; i < 12; i++)
		destroy_edge(&e[i]);
	printf("Edges destroyed successfully\n");
	for (i = 0; i < 8; i++)
		destroy_vertex(&v[i]);
	printf("Vertices destroyed successfully\n");
	destroy_graph(&g);
	printf("Graph destroyed successfully\n\n");

	printf("End: Testing remove_vertex_graph\n");
	printf("------------------------------\n\n");
	return;
}

