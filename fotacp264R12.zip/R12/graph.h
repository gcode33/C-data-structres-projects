/*
 -------------------------------------
 File:    graph.h
 Project: R12
 file description
 -------------------------------------
 Author:  your name here
 ID:      your ID here
 Email:   your Laurier email here
 Version  2022-07-18
 -------------------------------------
 */
/**
 * ------------------------------------------
 * Graph (header file)
 * Implementation: 	Adjacency matrix
 * Directed:		No
 * Weighted:		No
 * Loops?			No
 * ------------------------------------------
 */

#ifndef GRAPH_H_
#define GRAPH_H_

# define BLOCK 5
# define True 1
# define False 0

//---------- Vertex -----------

typedef struct {
	int uvid; //universal unique id
	int gvid; //graph unique vertex id
	char label[20]; //optional label
} Vertex;

Vertex* create_vertex(char *label);
void print_vertex(Vertex *v);
void destroy_vertex(Vertex **v);

//------------ Edge -----------

typedef struct {
	Vertex *v1;
	Vertex *v2;
} Edge;

Edge* create_edge(Vertex *v1, Vertex *v2);
void print_edge(Edge *e);
void destroy_edge(Edge **e);
int is_equal_edge(Edge *e1, Edge *e2);

//------------- Graph -----------

typedef struct {
	int **matrix; //adj matrix
	Vertex **vertices; //an array of pointers to vertices in grpah
	int vertex_count; //# of verticies in graph
	int edge_count; //#of edges in graph
	int _memory_size; //current rows in adj matrix
} Graph;

Graph* create_graph();
void destroy_graph(Graph **g);
void print_graph(Graph *g);
int is_null_graph(Graph *g);
int is_empty_graph(Graph *g);
int add_vertex_graph(Graph *g, Vertex *v);
int has_vertex_graph(Graph *g, Vertex *v);
int remove_vertex_graph(Graph *g, Vertex *v);
int add_edge_graph(Graph *g, Edge *e);
int has_edge_graph(Graph *g, Edge *e);
int remove_edge_graph(Graph *g, Edge *e);

#endif /* GRAPH_H_ */
