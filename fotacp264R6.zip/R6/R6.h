/*
 -------------------------------------
 File:    R6.h
 Project: R6
 file description
 -------------------------------------
 Author:  your name here
 ID:      your ID here
 Email:   your Laurier email here
 Version  2022-06-06
 -------------------------------------
 */
#ifndef R6_H_
#define R6_H_

# define MAX 100
# define MAX_WORD_LENGTH 30
# define MAX_LINE_LENGTH 250

void write_evens(const char *filename, int start, int end);
int read_numbers(const char *filename, int *array);

void copy_files1(const char *source, const char *destination);
void copy_files2(FILE *source, FILE *destinatination);

int copy_lines(const char *source, const char *destination);
int copy_words(const char *source, const char *destination);

int get_minutes1(const char *time);
int get_minutes2(const char *time);
int get_minutes3(const char *time);

int get_seconds(const char *time);
void fprint_record(char *record);

void modify_time(char *filename);

#endif /* R6_H_ */

