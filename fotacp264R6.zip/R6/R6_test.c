/*
 -------------------------------------
 File:    R6_test.c
 Project: R6
 file description
 -------------------------------------
 Author:  your name here
 ID:      your ID here
 Email:   your Laurier email here
 Version  2022-06-06
 -------------------------------------
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "R6.h"

void test_write_evens();
void test_read_numbers();

void test_copy_files1();
void test_copy_files2();

void test_copy_lines();
void test_copy_words();

void test_get_minutes1();
void test_get_minutes2();
void test_get_minutes3();

void test_get_seconds();
void test_fprint_record();

void test_modify_time();

//-------------------------------------
int main() {
	setbuf(stdout, NULL);
	test_write_evens();
	test_read_numbers();
	test_copy_files1();
	test_copy_files2();
	test_copy_lines();
	test_copy_words();
	test_get_minutes1();
	test_get_minutes2();
	test_get_minutes3();
	test_get_seconds();
	//test_fprint_record();
	test_modify_time();
	return 0;
}

void test_write_evens() {
	printf("------------------------------\n");
	printf("Start: Testing write_evens:\n\n");

	const char *name = "nums.txt";
	write_evens(name, 5, 22);

	printf("check file %s for output\n\n", name);

	printf("End: Testing write_evens\n");
	printf("------------------------------\n\n");
	return;
}

void test_read_numbers() {
	printf("------------------------------\n");
	printf("Start: Testing read_numbers:\n\n");

	const char *filename = "nums.txt";

	int nums[MAX];
	int counter = read_numbers(filename, nums);

	for (int i = 0; i < counter; i++) {
		if (i % 10 == 0 && i != 0)
			printf("\n");
		printf("%2d ", nums[i]);
	}
	printf("\n\nnumber of items = %d\n\n", counter);

	printf("End: Testing read_numbers\n");
	printf("------------------------------\n\n");
	return;
}

void test_copy_files1() {
	printf("------------------------------\n");
	printf("Start: Testing copy_files1:\n\n");

	printf("Case 1: valid source:\n");
	copy_files1("chistory.txt", "out.txt");
	printf("See out.txt for output\n\n");

	printf("Case 2: invalid source:\n");
	copy_files1("nothing.txt", "out.txt");
	printf("\n");

	printf("End: Testing copy_files1\n");
	printf("------------------------------\n\n");
	return;
}

void test_copy_files2() {
	printf("------------------------------\n");
	printf("Start: Testing copy_files2:\n\n");

	FILE *source = NULL, *destination = NULL;

	printf("Case 1: valid source:\n");
	source = fopen("chistory.txt", "r");
	if (source == NULL) {
		printf("Error(test_copy_file2): unable to open source file\n");
		return;
	}

	destination = fopen("out2.txt", "w");
	if (destination == NULL) {
		printf("Error(test_copy_file2): unable to open destination file\n");
		fclose(source);
		return;
	}

	copy_files2(source, destination);
	fclose(source);
	fclose(destination);
	printf("See out2.txt for output\n\n");

	printf("Case 2: invalid files:\n");
	copy_files2(NULL, destination);
	printf("\n");

	printf("End: Testing copy_files2\n");
	printf("------------------------------\n\n");
	return;
}

void test_copy_lines() {
	printf("------------------------------\n");
	printf("Start: Testing copy_lines:\n\n");

	printf("Case 1: valid source:\n");
	int lines = copy_lines("chistory.txt", "lines.txt");
	printf("#lines = %d\n", lines);
	printf("See lines.txt for output\n\n");

	printf("Case 2: invalid source:\n");
	lines = copy_lines("", "lines.txt");
	printf("#lines = %d\n\n", lines);

	printf("End: Testing copy_lines\n");
	printf("------------------------------\n\n");
	return;
}

void test_copy_words() {
	printf("------------------------------\n");
	printf("Start: Testing copy_words:\n\n");

	printf("Case 1: valid source:\n");
	int words = copy_words("chistory.txt", "words.txt");
	printf("#words = %d\n", words);
	printf("See words.txt for output\n\n");

	printf("Case 2: invalid source:\n");
	words = copy_words("", "words.txt");
	printf("#words = %d\n\n", words);

	printf("End: Testing copy_words\n");
	printf("------------------------------\n\n");
	return;
}

void test_get_minutes1() {
	printf("------------------------------\n");
	printf("Start: Testing get_minutes1:\n\n");

	char time[10];

	strcpy(time, "07:15:53");
	printf("time = %s --> mm = %d\n", time, get_minutes1(time));

	strcpy(time, "12:03:16");
	printf("time = %s --> mm = %d\n", time, get_minutes1(time));

	strcpy(time, "06:0n:59");
	printf("time = %s --> mm = %d\n", time, get_minutes1(time));

	strcpy(time, "04:78:24");
	printf("time = %s --> mm = %d\n", time, get_minutes1(time));

	printf("\n");

	printf("End: Testing get_minutes1\n");
	printf("------------------------------\n\n");
	return;
}
void test_get_minutes2() {
	printf("------------------------------\n");
	printf("Start: Testing get_minutes2:\n\n");

	char time[10];

	strcpy(time, "07:15:53");
	printf("time = %s --> mm = %d\n", time, get_minutes2(time));

	strcpy(time, "12:03:16");
	printf("time = %s --> mm = %d\n", time, get_minutes2(time));

	strcpy(time, "06:0n:59");
	printf("time = %s --> mm = %d\n", time, get_minutes2(time));

	strcpy(time, "04:78:24");
	printf("time = %s --> mm = %d\n", time, get_minutes2(time));

	printf("\n");

	printf("End: Testing get_minutes2\n");
	printf("------------------------------\n\n");
	return;
}

void test_get_minutes3() {
	printf("------------------------------\n");
	printf("Start: Testing get_minutes3:\n\n");

	char time[10];

	strcpy(time, "07:15:53");
	printf("time = %s --> mm = %d\n", time, get_minutes3(time));

	strcpy(time, "12:03:16");
	printf("time = %s --> mm = %d\n", time, get_minutes3(time));

	strcpy(time, "06:0n:59");
	printf("time = %s --> mm = %d\n", time, get_minutes3(time));

	strcpy(time, "04:78:24");
	printf("time = %s --> mm = %d\n", time, get_minutes3(time));

	printf("\n");

	printf("End: Testing get_minutes3\n");
	printf("------------------------------\n\n");
	return;
}

void test_get_seconds() {
	printf("------------------------------\n");
	printf("Start: Testing get_seconds:\n\n");

	char time[10];

	strcpy(time, "[07:15:53]");
	printf("time = %s --> seconds = %d\n", time, get_seconds(time));

	strcpy(time, "[12:03:6]");
	printf("time = %s --> seconds = %d\n", time, get_seconds(time));

	strcpy(time, "[6:1:59]");
	printf("time = %s --> seconds = %d\n", time, get_seconds(time));

	strcpy(time, "[04:78:84]");
	printf("time = %s --> seconds = %d\n", time, get_seconds(time));

	printf("\n");

	printf("End: Testing get_seconds\n");
	printf("------------------------------\n\n");
	return;
}
void test_fprint_record() {
	printf("------------------------------\n");
	printf("Start: Testing fprint_record:\n\n");

	char record[60];
	strcpy(record, "record:2018-June,14,1994-(David Smith)");
	fprint_record(record);
	printf("\n");

	printf("End: Testing fprint_record\n");
	printf("------------------------------\n\n");
	return;
}

void test_modify_time() {
	printf("------------------------------\n");
	printf("Start: Testing modify_time:\n\n");

	copy_files1("time1.txt", "seconds1.txt");
	modify_time("seconds1.txt");
	printf("check file seconds1.txt for output\n\n");

	printf("End: Testing modify_time\n");
	printf("------------------------------\n\n");
	return;
}

