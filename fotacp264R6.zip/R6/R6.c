/*
 -------------------------------------
 File:    R6.c
 Project: R6
 file description
 -------------------------------------
 Author:  your name here
 ID:      your ID here
 Email:   your Laurier email here
 Version  2022-06-06
 -------------------------------------
 */

# include <stdio.h>
# include <stdlib.h>
# include <string.h>
# include <ctype.h>
# include "R6.h"

int _is_valid_time(const char *time);

void write_evens(const char *filename, int start, int end) {
	//your code here
	FILE *out_file = NULL;
	out_file = fopen(filename, "w");
	if (out_file == NULL) {
		printf("Error(Write_evens): could not open file %s\n", filename);
		return;
	}
	for (int i = start; i <= end; i++)
		if (i % 2 == 0)
			fprintf(out_file, "%d\n", i++);

	fclose(out_file);
	return;
}

int read_numbers(const char *filename, int *array) {
	//your code here
	FILE *fptr = NULL;
	fptr = fopen(filename, "r");
	if (fptr == NULL) {
		printf("error(read_numbers): could not open file %s\n", filename);
		return -1;
	}
	int temp, i = 0;
	fscanf(fptr, "%d", &temp);
	while (!feof(fptr)) { //while we are not at the end of the file
		array[i++] = temp;
		fscanf(fptr, "%d", &temp);
	}

	fclose(fptr);
	return i;
}

void copy_files1(const char *source, const char *destination) {
	//your code here
	FILE *in_file = fopen(source, "r");
	if (in_file == NULL) {
		printf("error(copy_files1): unable to open source file\n");
		return;
	}
	FILE *out_file = fopen(destination, "w");
	if (out_file == NULL) {
		printf("error(copy_files1): unable to open destination file\n");
		fclose(in_file);
		return;
	}
	char ch;
	ch = fgetc(in_file);
	while (ch != EOF) {
		fputc(ch, out_file);
		ch = fgetc(in_file);
	}

	fclose(in_file);
	fclose(out_file);
	return;
}

void copy_files2(FILE *source, FILE *destination) {
	//your code here
	if (!source) {
		printf("error(copy_files2): invalid source file");
		return;
	}
	if (!destination) {
		printf("error(copy_files2): invalid destination");
		return;
	}
	char ch;
	ch = fgetc(source);
	while (!feof(source)) {
		fputc(ch, destination);
		ch = fgetc(source);
	}
	return;
}
//reads source file and counts number of non empty lines and writes them to destination and returns -1 if error
int copy_lines(const char *source, const char *destination) {
	//your code here
	FILE *in_file = fopen(source, "r");
	if (!in_file) {
		printf("error(copy_lines): unable to open source file");

		return -1;

	}
	FILE *out_file = fopen(destination, "w");
	if (!out_file) {
		printf("error(copy_lines): unable to find destination file");
		fclose(out_file);
		return -1;
	}
	int num_of_lines = 0;
	char buffer[MAX_LINE_LENGTH];
	while (fgets(buffer, MAX_LINE_LENGTH, in_file)) {
		if (buffer[0] != '\n') {
			fputs(buffer, out_file);
			num_of_lines++;
		}
	}
	fclose(in_file);
	fclose(out_file);
	return num_of_lines;
}
//reads source file
//counts and returns number of words
//writes each word on a separate line in description
//returns -1 if there is an error
int copy_words(const char *source, const char *destination) {
	//your code here
	FILE *in_file = fopen(source, "r");
	if (!in_file) {
		printf("error(copy_words): unable to open source file");

		return -1;

	}
	FILE *out_file = fopen(destination, "w");
	if (!out_file) {
		printf("error(copy_words): unable to find destination file");
		fclose(out_file);
		return -1;
	}
	int num_of_words = 0;
	char word[MAX_WORD_LENGTH];
	while (fscanf(in_file, "%s", word) != EOF) {
		fprintf(out_file, "%s\n", word);
		num_of_words++;
	}
	fclose(in_file);
	fclose(out_file);
	return num_of_words;
}

int _is_valid_time(const char *time) {
	if (strlen(time) != 8)
		return 0;
	for (int i = 0; i < 8; i++) {
		if (i == 2 || i == 5) {
			if (time[i] != ':') {
				return 0;
			}
		} else {
			if (!isdigit(time[i])) {
				return 0;
			}
		}

	}
	return 1;

}
//format hh:mm:ss
//manual method
int get_minutes1(const char *time) {
	//your code here
	int minutes = -1;
	int digit1, digit2;
	if (_is_valid_time(time)) {
		digit1 = 10 * (time[3] - '0');
		digit2 = time[4] - '0';
		minutes = digit1 + digit2;
		minutes = (minutes <= 59) ? minutes : -1; //first part before the question mark says that return mins based on the condition then afer th question mark set mins to -1

	}
	return minutes;
}
//use strtol
int get_minutes2(const char *time) {
	//your code here
	char mm[3], *end_pointer = NULL;
	int minutes = -1;
	if (_is_valid_time(time)) {
		mm[0] = time[3];
		mm[1] = time[4];
		mm[2] = '\0';
		minutes = (int) strtol(mm, &end_pointer, 10); //this converts it into mins so you can return
	}
	//minutes = (int)strtol(&time[3],&end_pointer,0)
	//printf("%s", *end_pointer);
	return (minutes >= 0 && minutes <= 59) ? minutes : -1;
}
//using sscanf
int get_minutes3(const char *time) {
	//your code here
	int hrs, mins, secs;
	char temp[0];
	if (_is_valid_time(time)) {
		strcpy(temp, time);
		sscanf(temp, "%d:%d:%d", &hrs, &mins, &secs);//scan the string and take the first vales and put it in hrs then mins then secs

	}
	return (mins >= 0 && mins <= 59) ? mins : -1;
}
//format [h:m:s] where it could be one or two digits
//manual method cant work here
int get_seconds(const char *time) {
	//your code here
	char *result[3];	//an array of three pointers
	char t[10];
	char *ptr;
	int secs = -1;
	strcpy(t, time);
	ptr = t;
	ptr++;//telling the ptr to move to a point that you wan to work with in the string

	result[0] = strtok(ptr, ":");//extract hours,strtok will make it stop and the :
	result[1] = strtok(NULL, ":");	//extract mins
	result[2] = strtok(NULL, "]");	//extract seconds
	sscanf(result[2], "%d", &secs);
	return (secs >= 0 && secs <= 59) ? secs : -1;
}

void fprint_record(char *record) {
	//your code here
	return;
}

void modify_time(char *filename) {
	//your code here
	FILE *in_file = fopen(filename, "r+");
	if (!in_file) {
		printf("could not open file %s for reading\n", filename);
		return;
	}
	char time[10], ss;
	int hh, mm;

	while (fgets(time, 10, in_file)) {
		sscanf(time, "%d:%d:%c", &hh, &mm, &ss);
		ss++;	//move to the next char
		fseek(in_file, -3, SEEK_CUR);//move the cursor one step back from the current position
		fputc(ss, in_file);
		fseek(in_file, 2, SEEK_CUR);
	}
	fclose(in_file);
	return;
}

void modify_time2(char *filename) {
	//your code here
	FILE *in_file = fopen(filename, "r+");
	if (!in_file) {
		printf("could not open file %s for reading\n", filename);
		return;
	}
	char time[10], ss;
	int line = 0, hh, mm;

	while (fgets(time, 10, in_file)) {
		sscanf(time, "%d:%d:%c", &hh, &mm, &ss);
		ss++;	//move to the next char
		fseek(in_file, 6 + 9 * line, SEEK_SET);	//move the cursor one step back from the current position
		fputc(ss, in_file);
		line++;
		fseek(in_file, 9 * line, SEEK_SET);	//move to the beginning to the next line
	}
	fclose(in_file);
	return;
}
