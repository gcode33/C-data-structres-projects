/*
 -------------------------------------
 File:    R5.c
 Project: R5
 file description
 -------------------------------------
 Author:  your name here
 ID:      your ID here
 Email:   your Laurier email here
 Version  2022-05-30
 -------------------------------------
 */

//put your include statements here
#include <stdio.h>
#include "R5.h"
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <stdbool.h>
//------------- Given Functions -------------
void print_array(int *array, const int size) {
	int i;
	printf("[");
	for (i = 0; i < size; i++) {
		printf("%d", array[i]);
		if (i != size - 1)
			printf(",");
	}
	printf("]\n");
	return;
}

int get_index_array(int *array, const int size, int value) {
	int i, indx = -1;
	for (i = 0; i < size; i++)
		if (array[i] == value) {
			indx = i;
			break;
		}
	return indx;
}

//------------- Task 1: Void Pointers -------------

void swap_void(void *var1, void *var2, char mode) {
	if (mode == 'i') { //i means integer
		int temp;
		temp = *(int*) var1;
		*(int*) var1 = *(int*) var2; //cast the void pointer then derefrence it
		*(int*) var2 = temp;
	} else if (mode == 'f') { //float
		float temp;
		temp = *(float*) var1;
		*(float*) var1 = *(float*) var2; //cast the void pointer then derefrence it
		*(float*) var2 = temp;

	} else if (mode == 'c') { //char/character
		char temp;
		temp = *(char*) var1;
		*(char*) var1 = *(char*) var2; //cast the void pointer then derefrence it
		*(char*) var2 = temp;

	} else
		printf("Error(swap_void): unsupported mode\n");

	//your code here
	return;
}

//------------- Task 2: Array of Pointers -------------

void find_max_min(int *array, const int size, int *ptr[2]) {
	if (!array)
		return;

	int i, max = 0;
	int min = 0;
	for (i = 0; i < size; i++) {
		if (array[i] > array[max]) {
			max = i;
		}
		if (array[i] < array[min]) {
			min = i;
		}
	}
	ptr[0] = &array[max];
	ptr[1] = &array[min];
	//your code here
	return;
}

//----------- Task 3: Dynamic Memory Allocation ---------------------
int* create_array1(int start, int end) {
	int n = end - start + 1;
	int *array = (int*) malloc(sizeof(int) * (n + 1)); //returns a pointer( a void pointer)need to cast
	for (int i = 0; i < n; i++)
		array[i] = start++;

	//your code here
	return array;
}

long* create_array2(long start, long end) {
	int n = end - start + 1;
	//long *array = (long*)malloc(n*sizeof(long));
	long *array = (long*) calloc(n, sizeof(long));
	for (int i = 0; i < n; i++)
		array[i] = start++;

	//your code here
	return array;
}

//------------------ Task 4: Expanding an array ----------------

void insert_array_item(int *array, const int size, int item, int pos) {
	if (!array) {
		printf("error(insert_item): invalid array\n");

	}
	if (pos >= size || pos < 0) {
		printf("error(insert_item): invalid position\n");
	}

	array = (int*) realloc(array, sizeof(int) * (size + 1));
	int i;
	for (i = size; i >= pos; i--)
		array[i + 1] = array[i];
	array[pos] = item;
	//your code here
	return;
}

//------------------ Task 5: Shrinking an array -----------------

void remove_array_item(int *array, const int size, int value) {
	if (!array) {
		printf("error(remove_array_item): invalid array\n");

	}
	int i, pos;
	pos = get_index_array(array, size, value);
	if (pos == -1) {
		printf("error(remove_array_item): item not found\n");
		return;
	}
	for (i = pos; i < size; i++)
		array[i] = array[i + 1];
	array = (int*) realloc(array, sizeof(int) * (size - 1));

	//your code here
	return;
}

//--------------- Task 6: initialize a string -------------------

void initialize_string() {
	char s1[MAX];
	strcpy(s1, "String1"); //every string has to end with a null character
	printf("s1 = %s, sizeof(s1) = %d\n", s1, sizeof(s1));

	//method2
	char s2[9] = { 's', 't', 'r', 'i', 'n', 'g', '2', '\0' };
	printf("s2 = %s, sizeof(s2) = %d\n", s2, sizeof(s2));

	//method3
	int size = strlen(s2);
	char *s3 = NULL;
	s3 = (char*) malloc(sizeof(char) * (size + 1));
	//s3 = malloc(size+1);this also works
	for (int i = 0; i < size; i++)
		s3[i] = s2[i];
	s3[size - 1] = '3';
	//strcpy(s2, "string3");//this also works for initilization
	printf("s3 = %s, sizeof(s3) = %d\n", s3, sizeof(s3));
	free(s3);
	s3 = NULL;

	//method4
	char *s4 = "String4";
	printf("s4 = %s, sizeof(s4) = %d\n", s4, sizeof(s4));

	//methd 5
	char s5[] = "String5";
	printf("s5 = %s, sizeof(s5) = %d\n", s5, sizeof(s5));

	//your code here
	return;
}

//------------------ Task 7: Reverse a string --------------------

void reverse_string1(char *s) {
	if (!s)
		return;
	strrev(s); //wrong approach function is no longer applicable
	//your code here
	return;
}
//change the strign in place
void reverse_string2(char *s) {
	if (!s || !*s)
		return;
	int temp;
	int i = 0;
	int size = 0;
	while (s[i] != '\0') {
		size++;
		i++;
	}
	for (i = 0; i < (size / 2); i++) {
		temp = *(s + i);	//temp = s[i]
		*(s + i) = *(s + size - i - 1);	//s[i] = s[size-i-1]
		*(s + size - i - 1) = temp;	//s[size-i-1] = temp
	}
	return;
	//find length of string size  = strl len(s); // mehtod one
}
//change original string anf return a pointer
char* reverse_string3(char *s) {
	if (!s || *s)
		return s;
	int size = strlen(s);
	int i = size - 1, j = 0;
	char temp;
	while (i > j) {
		temp = s[i];
		s[i--] = s[j];
		s[j++] = temp;
	}

	//your code here
	return s;
}
//get a reverse array copy the original is left unchanged
char* reverse_string4(char *s) {
	if (!s || !*s)
		return s;
	int size = strlen(s), j, i;
	char *s2 = (char*) malloc(sizeof(char) * (size + 1));
	strcpy(s2, s);
	char temp;
	i = size - 1;
	j = 0;
	while (i > j) {
		temp = s2[i];
		s2[i--] = s2[j];
		s2[j++] = temp;
	}
	//your code here
	return s;
}

//------------------ Task 8: Swapping strings --------------------
void swap_strings1(char *s1, char *s2) {
	int size1 = strlen(s1);
	char *temp = (char*) malloc(sizeof(char) * (size1 - 1));
	strcpy(temp, s1);
	strcpy(s1, s2);
	strcpy(s2, temp);
	free(temp);
	temp = NULL;
	//your code here
	return;
}
//using double pointers to just swap the pointer values
void swap_strings2(char **s1, char **s2) {
	char *temp = NULL;
	temp = *s1;
	*s1 = *s2;
	*s2 = temp;
	//your code here
	return;
}

//------------- Task 9: Character Operations ---------------------
//return true if string has two identical chars not nessicarilay consecutive
//count both upper and lower case chars(ignore the case)
int has_double(char *s) {
	int counters[26];
	int i = 0, index;

	//initialize cntrs
	for (int j = 0; j < 26; j++)
		counters[j] = 0;
	while (s[i])		//same as while s[i] != '\0'
	{
		if (isalpha(s[i])) {
			index = tolower(s[i] - 'a');
			counters[index]++;
			if (counters[index] == 2)
				return true;

		}
	}

	//your code here
	return false;
}
//a string is an array of type char ex char month[10] = {"january")
// an array of strings is a 2d array of chracters ex char months[12][10]
//any 2d array in C is equivalent to an array of pointers char months[11]
//which is also equivalent to a double pointer.
//
