/*
 -------------------------------------
 File:    R5.h
 Project: R5
 file description
 -------------------------------------
 Author:  your name here
 ID:      your ID here
 Email:   your Laurier email here
 Version  2022-05-30
 -------------------------------------
 */
#ifndef R5_H_
#define R5_H_

# define MAX 10

void print_array(int*, const int);
int get_index_array(int *array, const int size, int value);
void swap_void(void*, void*, char);
void find_max_min(int*, const int, int*[2]);
int* create_array1(int, int);
long* create_array2(long, long);
void insert_array_item(int*, const int, int, int);
void remove_array_item(int*, const int, int);
void initialize_string();
void reverse_string1(char*);
void reverse_string2(char*);
char* reverse_string3(char*);
char* reverse_string4(char*);
void swap_strings1(char*, char*);
void swap_strings2(char**, char**);
int has_double(char*);

#endif /* R5_H_ */
