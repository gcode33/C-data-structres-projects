/*
 -------------------------------------
 File:    R5_test.c
 Project: R5
 file description
 -------------------------------------
 Author:  your name here
 ID:      your ID here
 Email:   your Laurier email here
 Version  2022-05-30
 -------------------------------------
 */

# include "R5.h"
# include <stdio.h>
# include <stdlib.h>
# include <string.h>

void test_find_max_min();
void test_swap_void();
void test_create_array();
void test_resize_array();
void test_initialize_string();
void test_reverse_string();
void test_swap_strings();
void test_has_double();

int main() {
	setbuf(stdout, NULL);

	test_swap_void();
	test_find_max_min();
	test_create_array();
	test_resize_array();
	test_initialize_string();
	test_reverse_string();
	test_swap_strings();
	test_has_double();

	return 0;
}

void test_swap_void() {
	int n1 = 10, n2 = 20;
	char c1 = 'a', c2 = 'b';
	float f1 = 5.0, f2 = 6.0;
	double d1 = 5.0, d2 = 6.0;

	printf("------------------------------\n");
	printf("Start: Testing swap_void:\n\n");

	printf("Case 1: int swap:\n");
	printf("Before swap: n1 = %d, n2 = %d\n", n1, n2);
	swap_void(&n1, &n2, 'i');
	printf("After swap: n1 = %d, n2 = %d\n", n1, n2);
	printf("\n");

	printf("Case 2: char swap:\n");
	printf("Before swap: c1 = %c, c2 = %c\n", c1, c2);
	swap_void(&c1, &c2, 'c');
	printf("After swap: c1 = %c, c2 = %c\n", c1, c2);
	printf("\n");

	printf("Case 3: float swap:\n");
	printf("Before swap: f1 = %.1f, f2 = %.1f\n", f1, f2);
	swap_void(&f1, &f2, 'f');
	printf("After swap: f1 = %.1f, c2 = %.1f\n", f1, f2);
	printf("\n");

	printf("Case 4: double swap:\n");
	printf("Before swap: d1 = %.1lf, d2 = %.1lf\n", d1, d2);
	swap_void(&d1, &d2, 'd');
	printf("\n");

	printf("End: Testing swap_void\n");
	printf("------------------------------\n\n");
	return;
}

void test_find_max_min() {
	printf("------------------------------\n");
	printf("Start: Testing find_max_min:\n\n");

	int array[MAX] = { 40, 100, 30, 90, 20, 60, 10, 80, 50, 70 };
	int *ptr[2] = { NULL, NULL };
	printf("Array: [");
	for (int i = 0; i < MAX - 1; i++)
		printf("%d,", array[i]);
	printf("%d]\n", array[MAX - 1]);

	find_max_min(array, 10, ptr);
	printf("Max = %d at index = %d\n", *ptr[0], (ptr[0] - array));
	printf("Min = %d at index = %d\n", *ptr[1], (ptr[1] - array));
	printf("\n");

	find_max_min(&array[2], 4, ptr);
	printf("Max = %d at index = %d\n", *ptr[0], (ptr[0] - array));
	printf("Min = %d at index = %d\n", *ptr[1], (ptr[1] - array));
	printf("\n");

	printf("End: Testing find_max_min\n");
	printf("------------------------------\n\n");
	return;
}

void test_create_array() {
	printf("------------------------------\n");
	printf("Start: Testing create_array:\n\n");

	int *array = NULL, start = 10, end = 20;
	printf("Testing malloc:\n");
	array = create_array1(start, end);
	printf("array[0] = %d and array[%d] = %d\n", array[0], end - start,
			array[end - start]);
	//printf("Printing value outside array = %d\n", array[end - start + 1]);
	free(array);
	array = NULL;
	printf("\n");

	printf("Testing calloc:\n");
	start = 13;
	end = 28;
	long *array2 = NULL;
	array2 = create_array2((long) start, (long) end);
	printf("array[0] = %ld and array[%d] = %ld\n", array2[0], end - start,
			array2[end - start]);
	printf("Printing value outside array = %ld\n", array2[end - start + 1]);
	free(array2);
	array2 = NULL;
	printf("\n");

	printf("End: Testing create_array\n");
	printf("------------------------------\n\n");
	return;
}

void test_resize_array() {
	printf("------------------------------\n");
	printf("Start: Testing insert/remove:\n\n");

	int i, size = 10;
	int *array = (int*) malloc(sizeof(int) * size);
	for (i = 0; i < 10; i++)
		array[i] = i;
	printf("Before insert/remove\n");
	print_array(array, size);
	printf("After inserting 100 at position 3:\n");
	insert_array_item(array, size, 100, 3);
	size++;
	print_array(array, size);
	printf("After deleting value 8:\n");
	remove_array_item(array, size, 8);
	size--;
	print_array(array, size);
	printf("\n");
	free(array);
	array = NULL;

	printf("End: Testing insert/remove\n");
	printf("------------------------------\n\n");
	return;
}

void test_initialize_string() {
	printf("------------------------------\n");
	printf("Start: Testing initialize_string:\n\n");

	initialize_string();

	printf("\n");
	printf("End: Testing initialize_string\n");
	printf("------------------------------\n\n");
	return;
}

void test_reverse_string() {
	printf("------------------------------\n");
	printf("Start: Testing reverse_string:\n\n");

	char s1[MAX + 5], *s2;

	printf("Method 1:\n");
	strcpy(s1, "abcdefg");
	printf("Before: %s\n", s1);
	reverse_string1(s1);
	printf("After: %s\n", s1);
	strcpy(s1, "Good morning");
	printf("Before: %s\n", s1);
	reverse_string1(s1);
	printf("After: %s\n", s1);
	strcpy(s1, "");
	printf("Before: %s\n", s1);
	reverse_string1(s1);
	printf("After: %s\n", s1);
	printf("\n");

	printf("Method 2:\n");
	strcpy(s1, "abcdefg");
	printf("Before: %s\n", s1);
	reverse_string2(s1);
	printf("After: %s\n", s1);
	strcpy(s1, "Good morning");
	printf("Before: %s\n", s1);
	reverse_string2(s1);
	printf("After: %s\n", s1);
	strcpy(s1, "");
	printf("Before: %s\n", s1);
	reverse_string2(s1);
	printf("After: %s\n", s1);
	printf("\n");

	printf("Method 3:\n");
	strcpy(s1, "abcdefg");
	printf("Before: %s\n", s1);
	s2 = reverse_string3(s1);
	printf("After: original = %s, new = %s\n", s1, s2);
	strcpy(s1, "Good morning");
	printf("Before: %s\n", s1);
	s2 = reverse_string3(s1);
	printf("After: original = %s, new = %s\n", s1, s2);
	strcpy(s1, "");
	printf("Before: %s\n", s1);
	s2 = reverse_string3(s1);
	printf("After: original = %s, new = %s\n", s1, s2);
	printf("\n");

	printf("Method 4:\n");
	char *s3;
	strcpy(s1, "abcdefg");
	printf("Before: %s\n", s1);
	s3 = reverse_string4(s1);
	printf("After: original = %s, new = %s\n", s1, s3);
	free(s3);
	strcpy(s1, "Good morning");
	printf("Before: %s\n", s1);
	s3 = reverse_string4(s1);
	printf("After: original = %s, new = %s\n", s1, s3);
	free(s3);
	strcpy(s1, "");
	printf("Before: %s\n", s1);
	s3 = reverse_string4(s1);
	printf("After: original = %s, new = %s\n", s1, s3);
	printf("\n");
	free(s3);

	printf("End: Testing reverse_str\n");
	printf("------------------------------\n\n");
	return;
}

void test_swap_strings() {
	printf("------------------------------\n");
	printf("Start: Testing swap_strings:\n\n");

	char s1[] = "Day", s2[] = "Night";
	printf("Method 1:\n");
	printf("Before swap: s1 = %s , s2 = %s\n", s1, s2);
	swap_strings1(s1, s2);
	printf("After swap: s1 = %s , s2 = %s\n", s1, s2);
	printf("\n");

	char *s3 = "Day", *s4 = "Night";
	printf("Method 2:\n");
	printf("Before swap: s1 = %s , s2 = %s\n", s3, s4);
	swap_strings2(&s3, &s4);
	printf("After swap: s1 = %s , s2 = %s\n", s3, s4);
	printf("\n");

	printf("End: Testing swap_strings\n");
	printf("------------------------------\n\n");
	return;
}

void test_has_double() {
	printf("------------------------------\n");
	printf("Start: Testing has_double:\n\n");

	printf("has_double(\"\") = %d\n", has_double(""));
	printf("has_double(\"cat\") = %d\n", has_double("cat"));
	printf("has_double(\"seed\") = %d\n", has_double("seed"));
	printf("has_double(\"responsible\") = %d\n", has_double("responsible"));
	printf("has_double(\"$a$\") = %d\n", has_double("$a$"));
	printf("has_double(\"roar\") = %d\n", has_double("roar"));
	printf("has_double(\"Clock\") = %d\n", has_double("Clock"));
	printf("\n");

	printf("End: Testing has_double\n");
	printf("------------------------------\n\n");
	return;
}
