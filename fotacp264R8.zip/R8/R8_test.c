/*
 -------------------------------------
 File:    R8_test.c
 Project: R8
 file description
 -------------------------------------
 Author:  your name here
 ID:      your ID here
 Email:   your Laurier email here
 Version  2022-06-20
 -------------------------------------
 */
# include <stdio.h>
# include <stdlib.h>
# include <string.h>
# include "data.h"
# include "stack_array.h"
# include "queue_array.h"

void test_stack();
void test_queue();

int main() {
	setbuf(stdout, NULL);
	test_stack();
	test_queue();
	return 0;
}

void test_stack() {
	printf("------------------------------\n");
	printf("Start: Testing Stack:\n\n");

	int size = 10;

	printf("Stack* s = create_stack(10)\n");
	Stack *s = create_stack(size);
	printf("_print_stack(s):\n");
	_print_stack(s);
	printf("\n");

	printf("is_empty_stack(s): %d\n", is_empty_stack(s));
	printf("is_full_stack(s) : %d\n\n", is_full_stack(s));

	printf("push_stack(create_process(2000400, 23, 44,'R')):\n");
	printf("success = %d\n\n",
			push_stack(s, create_process(2000400, 23, 44, 'R')));
	printf("_print_stack(s):\n");
	_print_stack(s);
	printf("\n");

	printf("is_empty_stack(s): %d\n", is_empty_stack(s));
	printf("is_full_stack(s) : %d\n\n", is_full_stack(s));

	printf("Adding 9 elements to Stack:\n");
	short i, time = 10, arrival = 1;
	long pid = 1000100;
	for (i = 0; i < size - 1; i++) {
		push_stack(s, create_process(pid++, time++, arrival++, 'R'));
		_print_stack(s);
		printf("\n");
	}

	printf("is_full_stack(s) : %d\n\n", is_full_stack(s));

	printf("Calling push_stack:\n");
	printf("success = %d\n", push_stack(s, create_process(pid++, 59, 88, 'R')));
	printf("\n");

	printf("d = peek_stack(s)\n");
	Data *d = peek_stack(s);
	print_data(d);
	printf("\n\n");

	printf("d = pop_stack(s)\n");
	d = pop_stack(s);
	printf("Printing popped data:\n\t");
	print_data(d);
	printf("\nPrinting Stack: \n");
	_print_stack(s);
	printf("\n");
	destroy_data(d);

	printf("Popping 9 elements\n");
	for (i = 0; i < size - 1; i++) {
		d = pop_stack(s);
		printf("popped data:\n\t");
		print_data(d);
		printf("\nPrinting Stack: \n");
		_print_stack(s);
		printf("\n");
		destroy_data(d);
	}

	printf("pop_stack(s):  ");
	d = pop_stack(s);
	printf("peek_stack(s): ");
	d = peek_stack(s);
	printf("\n");

	printf("destroy_stack(&s):\n");
	destroy_stack(&s);
	if (!s)
		printf("stack destroyed successfully\n\n");

	printf("End: Testing Stack\n");
	printf("------------------------------\n\n");
	return;
}

void test_queue() {
	int size = 10;
	printf("------------------------------\n");
	printf("Start: Testing Queue:\n\n");

	printf("Calling Queue* q = create_queue(10), print_queue(q):\n");
	Queue *q = create_queue(size);
	_print_queue(q);
	printf("\n");

	printf("is_empty_queue(q): %d\n", is_empty_queue(q));
	printf("is_full_queue(q) : %d\n\n", is_full_queue(q));

	printf("insert_queue(create_process(2000400, 23, 44,'R')):\n");
	printf("success = %d\n\n",
			insert_queue(q, create_process(2000400, 23, 44, 'R')));
	printf("_print_queue(s):\n");
	_print_queue(q);
	printf("\n");

	printf("is_empty_queue(q): %d\n", is_empty_queue(q));
	printf("is_full_queue(q) : %d\n\n", is_full_queue(q));

	printf("Inserting 5 elements to queue:\n");
	short i, time = 10, arrival = 1;
	long pid = 1000100;
	for (i = 0; i < 5; i++) {
		insert_queue(q, create_process(pid++, time++, arrival++, 'R'));
		_print_queue(q);
		printf("\n");
	}

	printf("Removing 3 elements from queue:\n");
	Data *d = NULL;
	for (i = 0; i < 3; i++) {
		d = remove_queue(q);
		_print_queue(q);
		printf("\n");
		destroy_data(d);
	}

	printf("Inserting 4 elements to queue:\n");
	for (i = 0; i < 4; i++) {
		insert_queue(q, create_process(pid++, time++, arrival++, 'R'));
		_print_queue(q);
		printf("\n");
	}

	printf("Trigger adjust_queue:\n");
	insert_queue(q, create_process(pid++, time++, arrival++, 'R'));
	_print_queue(q);
	printf("\n");

	printf("Inserting 2 elements to queue:\n");
	for (i = 0; i < 2; i++) {
		insert_queue(q, create_process(pid++, time++, arrival++, 'R'));
		_print_queue(q);
		printf("\n");
	}
	printf("is_full_queue(q) : %d\n\n", is_full_queue(q));

	printf("Calling insert_queue:\n");
	printf("success = %d\n",
			insert_queue(q, create_process(pid++, 59, 88, 'R')));
	printf("\n");

	printf("d = peek_queue(q)\n");
	d = peek_queue(q);
	print_data(d);
	printf("\n\n");

	printf("d = remove_queue(q)\n");
	d = remove_queue(q);
	printf("Printing removed data:\n\t");
	print_data(d);
	printf("\nPrinting Queue: \n");
	_print_queue(q);
	printf("\n");
	destroy_data(d);

	printf("removing 9 elements\n");
	for (i = 0; i < size - 1; i++) {
		d = remove_queue(q);
		printf("removed data:\n\t");
		print_data(d);
		printf("\nPrinting Queue: \n");
		_print_queue(q);
		printf("\n");
		destroy_data(d);
	}

	printf("remove_queue(q):  ");
	d = remove_queue(q);
	printf("peek_queue(q): ");
	d = peek_queue(q);
	printf("\n");

	printf("destroy_queue(&q):\n");
	destroy_queue(&q);
	if (!q)
		printf("queue destroyed successfully\n\n");

	printf("End: Testing Queue\n");
	printf("------------------------------\n\n");
	return;
}
