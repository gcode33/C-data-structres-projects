/*
 -------------------------------------
 File:    process.h
 Project: R7
 file description
 -------------------------------------
 Author:  your name here
 ID:      your ID here
 Email:   your Laurier email here
 Version  2022-06-13
 -------------------------------------
 */

#ifndef PROCESS_H_
#define PROCESS_H_
#define True 1
#define False 0
typedef struct {
	long PID; //process id
	short arrival; //arrival time
	short service; //requested service time
	char priority; // r= regular, h = high, l = low
} Process;

Process* create_process(long, short, short, char);
void destroy_process(Process**);
Process* copy_process(Process*);
void process_to_str(Process*, char*);
void print_process(Process*);
int compare_process(Process*, Process*, char*);
long get_UPID();

#endif /* PROCESS_H_ */
