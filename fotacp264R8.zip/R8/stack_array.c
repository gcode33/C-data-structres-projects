/*
 -------------------------------------
 File:    stack_array.c
 Project: R8
 file description
 -------------------------------------
 Author:  your name here
 ID:      your ID here
 Email:   your Laurier email here
 Version  2022-06-20
 -------------------------------------
 */
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "stack_array.h"

Stack* create_stack(int capacity) {
	Stack *s = (Stack*) malloc(sizeof(Stack));
	if (capacity < 2) {
		printf(
				"Error(create_stack): invalid capacity, set to default value\n  ");
		capacity = STACK_DEFUALT_CAPACITY;
	}
	s->capacity = capacity;
	s->_array = (Data**) malloc(sizeof(Data*) * capacity);
	for (int i = 0; i < capacity; i++)
		s->_array[i] = NULL;

	s->_top = -1;
	return s;
}
Data* pop_stack(Stack *s) {
	assert(s);
	if (is_empty_stack(s)) {
		printf("Error(pop_stack): stack is empty\n");
		return NULL;
	}
	Data *temp = s->_array[s->_top];
	s->_array[s->_top] = NULL;
	s->_top--;
	return temp;
}
Data* peek_stack(Stack *s) {
	if (is_empty_stack(s)) {
		printf("Error(peek_stack): stack is empty\n");
	}
	return s->_array[s->_top]; //returning the array item at the top
}
int push_stack(Stack *s, Data *d) { //push something into the stack and return if it worked or not
	if (is_full_stack(s)) {
		printf("Error(push_stack): Stack is full\n");
		return False;
	}
	s->_top++;
	s->_array[s->_top] = d;
	return 0;
}

int is_empty_stack(Stack *s) {
	assert(s);
	return (s->_top == -1);
}
int is_full_stack(Stack *s) {
	assert(s);

	return (s->_top == s->capacity - 1);
}
void destroy_stack(Stack **s) {
	assert(s && *s);
	while (!is_empty_stack(*s))
		pop_stack(*s);
	free((*s)->_array);
	(*s)->_array = NULL;
	(*s)->_top = 0;
	(*s)->capacity = 0;

	free(*s);
	*s = NULL;
	return;
}
int len_stack(Stack *s) {
	assert(s);
	return s->_top + 1;

}
void _print_stack(Stack *s) {
	assert(s != NULL);
	printf("stack size = %d\n", len_stack(s));
	if (is_empty_stack(s))
		printf("empty_stack\n");
	for (int i = s->_top; i >= 0; i--) {
		print_data(s->_array[i]);
		printf("\n");
	}
	return;
}
