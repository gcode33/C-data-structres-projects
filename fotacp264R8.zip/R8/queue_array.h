/*
 -------------------------------------
 File:    qeuearray.h
 Project: R8
 file description
 -------------------------------------
 Author:  your name here
 ID:      your ID here
 Email:   your Laurier email here
 Version  2022-06-22
 -------------------------------------
 */

#ifndef QUEUE_ARRAY_H_
#define QUEUE_ARRAY_H_
#include "data.h"
#define DEFAULT_QUEUE_CAPACITY 10
#define True 1
#define False 0

typedef struct {
	int capacity; //length of qeue
	Data **_array; // array containing pointers to data time
	int _front; //index of first item in queue
	int _rear; //index of last item in the queue
} Queue;

Queue* create_queue(int capacity);
Data* remove_queue(Queue *q);
void destroy_queue(Queue **q); //need double pointer because we are changing the pointer
Data* peek_queue(Queue *q);
int is_empty_queue(Queue *q);
int is_full_queue(Queue *q);
int insert_queue(Queue *q, Data *d);
void _print_queue(Queue *q);
int len_queue(Queue *q);
#endif /* QUEUE_ARRAY_H_ */
