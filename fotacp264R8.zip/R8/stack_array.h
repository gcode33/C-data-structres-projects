/*
 -------------------------------------
 File:    stack_array.h
 Project: R8
 file description
 -------------------------------------
 Author:  your name here
 ID:      your ID here
 Email:   your Laurier email here
 Version  2022-06-20
 -------------------------------------
 */

#ifndef STACK_ARRAY_H_
#define STACK_ARRAY_H_
#define STACK_DEFUALT_CAPACITY 10
#include "data.h"
typedef struct {
	Data **_array; //an array of pointers to data items(_ means private)
	int _top; //index of top item in stack
	int capacity; //max number of items in stack

} Stack;

Stack* create_stack(int);
Data* pop_stack(Stack*);
Data* peek_stack(Stack*);
int push_stack(Stack*, Data*); //push something into the stack and return if it worked or not
int is_empty_stack(Stack*);
int is_full_stack(Stack*);
void destroy_stack(Stack**);
int len_stack(Stack*);
void _print_stack(Stack*);

#endif /* STACK_ARRAY_H_ */
