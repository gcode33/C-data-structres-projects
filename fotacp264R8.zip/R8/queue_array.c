/*
 -------------------------------------
 File:    qeue_array.c
 Project: R8
 file description
 -------------------------------------
 Author:  your name here
 ID:      your ID here
 Email:   your Laurier email here
 Version  2022-06-22
 -------------------------------------
 */
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <stdbool.h>
#include "queue_array.h"
void _adjust_queue(Queue *q);

Queue* create_queue(int capacity) {
	Queue *q = (Queue*) malloc(sizeof(Queue));
	if (capacity > 2) {
		printf("Error(create_queue): invalid capacity, set to default value");
		capacity = DEFAULT_QUEUE_CAPACITY;
	}
	q->capacity = capacity;
	q->_array = (Data**) malloc(sizeof(Data*) * capacity);
	for (int i = 0; i < capacity; i++)
		q->_array[i] = NULL;

	q->_front = -1;
	q->_rear = -1;

	return q;
}
int len_queue(Queue *q) {
	assert(q); //to say that q is not NULL
	if (q->_front == -1)  //empty queue
		return 0;
	return q->_rear - q->_front + 1;
}
int is_empty_queue(Queue *q) {
	assert(q);
	return (len_queue(q) == 0);
	//return (q->_front == -1);
}

int is_full_queue(Queue *q) {
	assert(q);
	int length = q->_rear - q->_front + 1;
	return (length == q->capacity);
	//(return(len_queue(q) == q->_capacity);
}
//O(1)
Data* peek_queue(Queue *q) {
	assert(q);
	if (is_empty_queue(q)) {
		printf("Error(peek_queue): queue is empty");
		return NULL;
	}
	return q->_array[q->_front];
}
//O(1)
Data* remove_queue(Queue *q) {
	assert(q);
	if (is_empty_queue(q)) {
		printf("Error(remove_queue): queue is empty\n");
		return NULL;
	}
	Data *temp = q->_array[q->_front];
	q->_array[q->_front] = NULL;
	q->_front++;
	if (len_queue(q) == 0) {
		q->_front = -1;
		q->_rear = -1;
	}
	return temp;
}
//worst case O(n), best case O(1)
int insert_queue(Queue *q, Data *d) {
	assert(q);
	if (is_full_queue(q)) {
		printf("Error(insert_queue): queue is full\n");
		return False;
	}
	//case 1 = empty
	if (is_empty_queue(q)) {
		q->_front = 0;
	} else if (q->_rear == q->capacity - 1) { //case3
		_adjust_queue(q); //O(n)
	}
	//case2 = simple insert
	q->_rear++;
	q->_array[q->_rear] = d;
	return True;
	q->_rear++;
}

void _adjust_queue(Queue *q) {
	assert(q);
	int i, length = len_queue(q);
	for (i = 0; i < len_queue(q); i++)
		q->_array[i] = q->_array[i + q->_front];
	for (i = length; i < q->capacity; i++)
		q->_array[i] = NULL;
	q->_front = 0;
	q->_rear = length - 1;
	return;
}

void destroy_queue(Queue **q) {
	assert(q && *q);
	while (!is_empty_queue(*q))
		remove_queue(*q);
	for (int i = 0; i < (*q)->capacity; i++)
		(*q)->_array[i] = NULL;
	free((*q)->_array);
	(*q)->capacity = 0;
	(*q)->_front = 0;
	(*q)->_rear = 0;
	free(*q);
	*q = NULL;
	return;
}

void _print_queue(Queue *q) {
	assert(q != NULL);
	int i;
	printf("Capacity = %d  Size = %d	front = %d	rear = %d\n", q->capacity,
			len_queue(q), q->_front, q->_rear);
	if (is_empty_queue(q))
		printf("empty queue\n");
	else {
		int counter = 0;
		for (i = q->_front; i <= q->_rear; i++) {
			print_data(q->_array[i]);
			if ((counter + 1) % 5 == 0 && counter != len_queue(q) - 1)
				printf("\n");
			else
				printf("\t");
			counter++;
		}
		printf("\n");

	}
	return;
}
