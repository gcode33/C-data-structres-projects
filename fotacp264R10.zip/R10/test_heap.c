/*
 -------------------------------------
 File:    test_heap.c
 Project: R10
 file description
 -------------------------------------
 Author:  your name here
 ID:      your ID here
 Email:   your Laurier email here
 Version  2022-07-06
 -------------------------------------
 */

# include <stdio.h>
# include <stdlib.h>
# include <assert.h>

#include "heap.h"

void test_basic_heap();
void test_RLP();
void test_insert_heap();
void test_remove_heap();
void test_heap_sort();
void test_find_max_min_heap();
void print_data_array(Data **array, const int size);

int main() {
	setbuf(stdout, NULL);
	test_basic_heap();
	test_RLP();
	test_insert_heap();
	test_remove_heap();
	test_heap_sort();
	test_find_max_min_heap();
	return 0;
}

void test_basic_heap() {
	printf("------------------------------\n");
	printf("Start: Testing heap basic functions:\n\n");

	Heap *h = create_heap();
	if (h)
		printf("heap created successfully with capacity 20\n\n");

	printf("print contents of heap:\n");
	_print_heap(h);
	printf("\n");

	printf("is_empty_heap(h)? %d\n", is_empty_heap(h));
	printf("len_heap(h) = %d\n", len_heap(h));
	printf("h->_memory_size = %d\n", h->_memory_size); //for testing only
	peek_heap(h);
	printf("\n");

	destroy_heap(&h);
	if (!h)
		printf("heap successfully destroyed\n\n");

	printf("End: Testing heap basic functions\n");
	printf("------------------------------\n\n");
}

void test_RLP() {
	printf("------------------------------\n");
	printf("Start: Testing Right(i), Left(i), Parent(i):\n\n");

	int i;
	Heap *h = create_heap();
	printf("Creating a heap:\n");

	int values[10] = { 100, 80, 90, 60, 70, 10, 50, 20, 30, 40 };
	Data **array = (Data**) malloc(sizeof(Data*) * 20);
	for (i = 0; i < 10; i++)
		array[i] = &values[i];

	printf("Manual insertion into heap array\n");
	for (i = 0; i < 10; i++)
		h->_array[i] = array[i];
	h->_size = 10;

	_print_heap(h);
	printf("\n");

	for (i = 0; i < 10; i++)
		printf("i = %d\t Parent(i) = %d\t Left(i) = %d\t Right(i) = %d\n", i,
				Parent(i), Left(i), Right(i));
	printf("\n");

	//manually destroy heap and array
	free(array);
	array = NULL;
	free(h);
	h = NULL;

	printf("End: Testing Right(i), Left(i), Parent(i)\n");
	printf("------------------------------\n\n");

	return;
}

void test_insert_heap() {
	printf("------------------------------\n");
	printf("Start: Testing insert_heap:\n\n");

	printf("Create an empty heap\n");
	Heap *h = create_heap();
	_print_heap(h);
	printf("\n");

	int values[12] = { 40, 70, 10, 30, 90, 50, 100, 20, 60, 80, 110, 120 };
	int i;
	Data **array = (Data**) malloc(sizeof(Data*) * 20);
	for (i = 0; i < 12; i++)
		array[i] = &values[i];

	for (i = 0; i < 12; i++) {
		printf("insert ");
		print_data(array[i]);
		printf("\n");
		insert_heap(h, array[i]);
		_print_heap(h);
		printf("\n");
	}

	printf("peek_heap = ");
	print_data(peek_heap(h));
	printf("\n\n");

	free(h);
	h = NULL;
	free(array);
	array = NULL;

	printf("End: Testing insert_heap\n");
	printf("------------------------------\n\n");

}
void test_remove_heap() {
	printf("------------------------------\n");
	printf("Start: Testing remove_heap:\n\n");

	printf("Create an empty heap\n");
	Heap *h = create_heap();
	_print_heap(h);
	printf("\n");

	int values[12] = { 40, 70, 10, 30, 90, 50, 100, 20, 60, 80, 110, 120 };
	int i;
	Data **array = (Data**) malloc(sizeof(Data*) * 20);
	for (i = 0; i < 12; i++)
		array[i] = &values[i];

	printf("Insert 12 items:\n");
	for (i = 0; i < 12; i++)
		insert_heap(h, array[i]);

	_print_heap(h);
	printf("\n");

	printf("Removing items:\n");
	for (i = 0; i < 12; i++) {
		remove_heap(h);
		_print_heap(h);
		printf("\n");
	}

	destroy_heap(&h);
	free(array);
	array = NULL;

	printf("End: Testing remove_heap\n");
	printf("------------------------------\n\n");
}

void test_heap_sort() {
	printf("------------------------------\n");
	printf("Start: Testing heap_sort:\n\n");

	int i, size = 12;
	int values[12] = { 40, 70, 10, 30, 90, 50, 100, 20, 60, 80, 110, 120 };
	Data **array = (Data**) malloc(sizeof(Data*) * 12);
	for (i = 0; i < size; i++)
		array[i] = &values[i];

	printf("Printing array before sorting: \n");
	print_data_array(array, size);
	printf("\n");

	heap_sort(array, size);
	printf("Printing array after sorting: \n");
	print_data_array(array, size);
	printf("\n");

	free(array);
	array = NULL;
	printf("End: Testing heap_sort\n");
	printf("------------------------------\n\n");

	return;
}

void test_find_max_min_heap() {
	printf("------------------------------\n");
	printf("Start: Testing find_max_heap and find_min_heap:\n\n");

	printf("Create an empty heap\n");
	Heap *h = create_heap();
	_print_heap(h);
	printf("\n");

	int values[12] = { 40, 70, 80, 30, 90, 50, 60, 20, 100, 10, 110, 120 };
	int i;
	Data **array = (Data**) malloc(sizeof(Data*) * 20);
	for (i = 0; i < 12; i++)
		array[i] = &values[i];

	for (i = 0; i < 12; i++) {
		insert_heap(h, array[i]);
		printf("heap = ");
		_print_heap(h);
		printf("max = ");
		print_data(find_max_heap(h));
		printf("\nmin = ");
		print_data(find_min_heap(h));
		printf("\n\n");
	}

	destroy_heap(&h);
	free(array);
	array = NULL;

	printf("End: Testing find_max_heap and find_min_heap\n");
	printf("------------------------------\n\n");

	return;
}

void print_data_array(Data **array, const int size) {
	assert(array);
	assert(size >= 1);

	int i;
	printf("[");
	for (i = 0; i < size; i++) {
		print_data(array[i]);
		if (i != size - 1)
			printf(",");
	}
	printf("]\n");
	return;
}
