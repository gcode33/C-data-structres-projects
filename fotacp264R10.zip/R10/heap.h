/*
 -------------------------------------
 File:    heap.h
 Project: R10
 file description
 -------------------------------------
 Author:  your name here
 ID:      your ID here
 Email:   your Laurier email here
 Version  2022-07-06
 -------------------------------------
 */

#ifndef HEAP_H_
#define HEAP_H_

//Max heap array implementation
#include "Data.h"
#define True 1
#define False 0
#define Left(i) (2*i+1)
#define Right(i) (2*i + 2)
#define Parent(i) ((i-1)/2)
#define BLOCK 10

typedef struct {
	Data **_array;
	int _size;
	int _memory_size; //maintain the size that is being clamind by the heap and memory
} Heap;
Heap* create_heap();
int is_empty_heap(Heap*);
int len_heap(Heap*);
void destroy_heap(Heap**);
void insert_heap(Heap*, Data*);
Data* peek_heap(Heap*);
Data* remove_heap(Heap*);
void _print_heap(Heap*);
void heap_sort(Data**, const int);
Data* find_max_heap(Heap*);
Data* find_min_heap(Heap*);

#endif /* HEAP_H_ */
