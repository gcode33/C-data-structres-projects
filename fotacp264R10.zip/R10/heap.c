/*
 -------------------------------------
 File:    heap.c
 Project: R10
 file description
 -------------------------------------
 Author:  your name here
 ID:      your ID here
 Email:   your Laurier email here
 Version  2022-07-06
 -------------------------------------
 */

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "heap.h"
void _heapify_up(Heap*, int i);
int _contains_heap(Heap *h, Data *d);
void _swap_data(Data **d1, Data **d2);
void _heapify_down(Heap *h, int i);

void _swap_data(Data **d1, Data **d2) {
	Data *temp = *d1;
	*d1 = *d2;
	*d2 = temp;
	return;
}
Heap* create_heap() {
	Heap *h = (Heap*) malloc(sizeof(Heap));
	h->_memory_size = BLOCK;
	h->_array = (Data**) malloc(sizeof(Data*) * h->_memory_size);
	for (int i = 0; i < h->_memory_size; i++)
		h->_array[i] = NULL;
	h->_size = 0;
	return h;
}
int is_empty_heap(Heap *h) {
	assert(h);
	return (h->_size == 0);
}
int len_heap(Heap *h) {
	assert(h);
	return h->_size;
}
void destroy_heap(Heap **h) {
	assert(h && *h);
	while (!is_empty_heap(*h))
		remove_heap(*h);
	free((*h)->_array);
	(*h)->_array = NULL;
	(*h)->_size = 0;
	(*h)->_memory_size = 0;
	free(*h);
	*h = NULL;
	return;
}
//O(log(n))
void insert_heap(Heap *h, Data *d) {
	assert(h && d);
	//if(_contains_heap(h,d)){
	//printf("error(insert_heap): cannot insert duplicate\n");
	//}
	if (h->_memory_size == h->_size) {	//double memory size when full
		h->_memory_size = h->_memory_size * 2;
		h->_array = (Data**) realloc(h->_array,
				sizeof(Data*) * h->_memory_size);
	}
	h->_array[h->_size] = d;
	h->_size++;
	_heapify_up(h, h->_size - 1);
	return;
}
//O(log(n))
void _heapify_up(Heap *h, int i) {
	assert(h);
	if (i <= 0)	//base case
		return;
	if (compare_data(h->_array[i], h->_array[Parent(i)]) == 1)	//child > parent
		_swap_data(&h->_array[i], &h->_array[Parent(i)]);

	_heapify_up(h, Parent(i));

}
//0(1)
Data* peek_heap(Heap *h) {
	assert(h);
	if (is_empty_heap(h)) {
		printf("error(peek_heap):heap is empty\n");
		return NULL;
	}
	return h->_array[0];
}
void _print_heap(Heap *h) {
	assert(h);
	printf("heap size is = %d memory_size = %d\n", h->_size, h->_memory_size);
	if (is_empty_heap(h)) {
		printf("empty heap\n");
		return;
	}
	print_data(h->_array[h->_size - 1]);
	printf("]\n");
	return;
}

Data* remove_heap(Heap *h) {
	assert(h);
	if (is_empty_heap(h)) {
		printf("Error(remove_heap): heap is empty\n");
		return NULL;
	}
	Data *removed_item = h->_array[0];
	h->_array[0] = h->_array[h->_size - 1];
	h->_size--;
	//if less than 1/3 of heap occupieed shrinnk memory
	if (h->_size < h->_memory_size / 3) {
		h->_memory_size = h->_memory_size / 2;
		h->_memory_size = (h->_memory_size < BLOCK) ? BLOCK : h->_memory_size;
		h->_array = (Data**) realloc(h->_array,
				sizeof(Data*) * h->_memory_size);
	}
	_heapify_down(h, 0);
	return removed_item;
}

void _heapify_down(Heap *h, int i) {
	assert(h);
	//base cases
	//1 empty heap
	//2single node heap
	//3 reached leaf node
	if (h->_size <= 1 || i >= h->_size - 1)
		return;
	int max_index = i;

	//if left child is larger than current
	if (Left(i) < h->_size
			&& compare_data(h->_array[i], h->_array[Left(i)]) == 2)
		max_index = Left(i);

	//if right is the largest
	if (Right(i) < h->_size
			&& compare_data(h->_array[max_index], h->_array[Right(i)]) == 2)
		max_index = Right(i);

	//no swap needed stop recursion
	if (max_index == i)
		return;

	//swap data oone node down
	_swap_data(&h->_array[i], &h->_array[max_index]);
	_heapify_down(h, max_index);
	return;
}
//all 0(n*log(n))
void heap_sort(Data **array, const int size) {
	assert(array);
	Heap *h = (Heap*) malloc(sizeof(Heap));
	int i;
	for (i = 0; i < size; i++)
		insert_heap(h, array[i]);
	for (i = 0; i < size; i++)
		*(array)[i] = *remove_heap(h);

	destroy_heap(&h);
	return;
}
//0(1)
Data* find_max_heap(Heap *h) {
	assert(h);
	if (is_empty_heap(h)) {
		printf("Error(find_max_min): empty heap\n");
		return NULL;

	}
	return h->_array[0];
}

Data* find_min_heap(Heap *h) {

	assert(h);
	if (is_empty_heap(h)) {
		printf("Error(find_min_heap): empty heap\n");
		return NULL;
	}
	//we only need to check the leaf nodes
	int min_index = h->_size / 2;	// there are ceil(n/2) leaf nodes at most
	int i;
	for (i = min_index; i < h->_size; i++)
		if (compare_data(h->_array[i], h->_array[min_index]) == 2)
			min_index = i;
	return h->_array[min_index];
}
//O(n)
int _contains_heap(Heap *h, Data *d) {
	assert(h && d);
	if (is_empty_heap(h))
		return False;
	for (int i = 0; i < h->_size; i++)
		if (compare_data(d, h->_array[i]) == 0)
			return True;
	return False;
}
