/*
 -------------------------------------
 File:    data.h
 Project: R7
 file description
 -------------------------------------
 Author:  your name here
 ID:      your ID here
 Email:   your Laurier email here
 Version  2022-06-13
 -------------------------------------
 */

#ifndef DATA_H_
#define DATA_H_

typedef int Data;

void print_data(Data *d);
void destroy_data(Data *d);
Data* copy_data(Data *d);
int compare_data(Data *d1, Data *d2);

#endif /* DATA_H_ */
