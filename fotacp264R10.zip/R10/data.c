/*
 -------------------------------------
 File:    data.c
 Project: R7
 file description
 -------------------------------------
 Author:  your name here
 ID:      your ID here
 Email:   your Laurier email here
 Version  2022-06-13
 -------------------------------------
 */
#include <stdio.h>
#include <assert.h>
#include "data.h"

void print_data(Data *d) {
	assert(d);
	printf("%d", d);
	return;
}
void destroy_data(Data *d) {
	assert(d);
	free(*d);
	*d = NULL;
	return;
}
Data* copy_data(Data *d1) {
	assert(d1);
	int *d2 = (int*) malloc(sizeof(int));
	*d2 = *d1;
	return d2;
}
int compare_data(Data *d1, Data *d2) {
	assert(d1 && d2);
	if (*d1 > *d2)
		return 1;
	if (*d1 < *d2)
		return 0;
	return 2; //equal
}

