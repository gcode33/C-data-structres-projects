/*
 -------------------------------------
 File:    R7.c
 Project: R7
 file description
 -------------------------------------
 Author:  your name here
 ID:      your ID here
 Email:   your Laurier email here
 Version  2022-06-13
 -------------------------------------
 */
# include <stdio.h>
# include <stdlib.h>
# include <string.h>
# include "process.h"
# include "data.h"
//# include "stack_array.h"

void test_process();
void test_data();
//void test_stack();

int main() {
	setbuf(stdout, NULL);
	test_process();
	test_data();
	//test_stack();
	return 0;
}

void test_process() {
	printf("------------------------------\n");
	printf("Start: Testing Process structure:\n\n");

	printf("Testing create_process:\n");
	printf("\tProcess* p1 = create_process(1055104,40,10,'R'):\n");
	Process *p1 = create_process(1055104, 40, 10, 'R');
	printf("\tPID     = %ld\n", p1->PID);
	printf("\tarrival = %hd\n", p1->arrival);
	printf("\tservice = %hd\n", p1->service);
	printf("\tpriority = %c\n", p1->priority);
	printf("\n");

	printf("Testing process_to_str:\n");
	char str[30] = "";
	printf("\tprocess_to_str(p1,info)\n");
	process_to_str(p1, str);
	printf("\tstr = %s\n", str);
	printf("\n");

	printf("Testing print_process:\n");
	printf("\tprint_process(p1):\n\t");
	print_process(p1);
	printf("\n\n");

	Process *p2 = create_process(6003244, 38, 16, 'H');
	printf("Creating Process p2:\n\t");
	print_process(p2);
	printf("\n\n");

	printf("Testing copy_process:\n");
	printf("\tProcess* p3 = copy_process(p2):\n");
	printf("\tprint_process(p3):\n\t");
	Process *p3 = copy_process(p2);
	print_process(p3);
	printf("\n\n");

	printf("Testing compare_process:\n");
	printf("\tcompare_process(p2,p3,S) = %d\n", compare_process(p2, p3, "S"));
	printf("\tcompare_process(p2,p3,AS) = %d\n", compare_process(p2, p3, "AS"));
	printf("\tcompare_process(p1,p2,S) = %d\n", compare_process(p1, p2, "S"));
	printf("\tcompare_process(p1,p3,AS) = %d\n\n",
			compare_process(p1, p3, "AS"));

	printf("Testing destroy_process:\n");
	destroy_process(&p1);
	destroy_process(&p2);
	destroy_process(&p3);
	if (!p1 && !p2 && !p3)
		printf("\tprocesses p1, p2 and p3 destroyed successfully\n\n");

	printf("Testing get_UPID:\n");
	for (int i = 0; i < 3; i++)
		printf("\t%ld\n", get_UPID());
	printf("\n");

	printf("End: Testing Process Structure\n");
	printf("------------------------------\n\n");
	return;
}

void test_data() {
	printf("------------------------------\n");
	printf("Start: Testing Data:\n\n");

	int size = 10, i;
	Data *array = (Data*) malloc(sizeof(Data) * size);
	int pid = 1000100, arrival = 30, service = 1;
	for (i = 0; i < size; i++)
		array[i] = *create_process(pid++, service++, arrival++, 'R');
	printf("Testing print Data:\n");
	for (i = 0; i < size; i++) {
		print_data(&array[i]);
		printf("\n");
	}
	printf("\n");
	printf("Testing Copy Data - copy last element to first element:\n");
	array[0] = *copy_data(&array[size - 1]);
	for (i = 0; i < size; i++) {
		print_data(&array[i]);
		printf("\n");
	}
	printf("\n");

	printf("Testing destroy_data:\n");
	for (i = 1; i < 10; i++)
		destroy_data(&array[i]);
	printf("\tdestroy_data successful\n");
	printf("\n");

	free(array);
	array = NULL;

	printf("End: Testing Data\n");
	printf("------------------------------\n\n");
	return;
}

/*void test_stack() {
 printf("------------------------------\n");
 printf("Start: Testing Stack:\n\n");

 int size = 10;

 printf("--------- Testing Create/isEmpty/print ----------- \n");
 printf("Stack* s = create_stack(10)\n");
 Stack *s = create_stack(size);
 printf("_print_stack(s):\n");
 _print_stack(s);
 printf("\n");

 printf("is_empty_stack(s): %d\n", is_empty_stack(s));
 printf("is_full_stack(s) : %d\n\n", is_full_stack(s));

 printf("push_stack(create_process(2000400, 23, 44,'R')):\n");
 printf("success = %d\n\n",
 push_stack(s, create_process(2000400, 23, 44, 'R')));
 printf("_print_stack(s):\n");
 _print_stack(s);
 printf("\n");

 printf("is_empty_stack(s): %d\n", is_empty_stack(s));
 printf("is_full_stack(s) : %d\n\n", is_full_stack(s));

 printf("Adding 9 elements to Stack:\n");
 short i, time = 10, arrival = 1;
 long pid = 1000100;
 for (i = 0; i < size - 1; i++) {
 push_stack(s, create_process(pid++, time++, arrival++, 'R'));
 _print_stack(s);
 printf("\n");
 }

 printf("is_full_stack(s) : %d\n\n", is_full_stack(s));

 printf("Calling push_stack:\n");
 printf("success = %d\n", push_stack(s, create_process(pid++, 59, 88, 'R')));
 printf("\n");

 printf("d = peek_stack(s)\n");
 Data *d = peek_stack(s);
 print_data(d);
 printf("\n\n");

 printf("d = pop_stack(s)\n");
 d = pop_stack(s);
 printf("Printing popped data:\n\t");
 print_data(d);
 printf("\nPrinting Stack: \n");
 _print_stack(s);
 printf("\n");
 destroy_data(d);

 printf("Popping 9 elements\n");
 for (i = 0; i < size - 1; i++) {
 d = pop_stack(s);
 printf("popped data:\n\t");
 print_data(d);
 printf("\nPrinting Stack: \n");
 _print_stack(s);
 printf("\n");
 destroy_data(d);
 }

 printf("pop_stack(s):  ");
 d = pop_stack(s);
 printf("peek_stack(s): ");
 d = peek_stack(s);
 printf("\n");

 printf("destroy_stack(&s):\n");
 destroy_stack(&s);
 if (!s)
 printf("stack destroyed successfully\n\n");

 printf("End: Testing Stack\n");
 printf("------------------------------\n\n");
 return;
 }*/

