/**
 * -------------------------
 * Student Name:George Fotabong
 * Student ID:200484320
 * Student email:fota4320@mylaurier.ca
 * -------------------------
 */

# include <stdio.h>
# include <stdlib.h>
# include <assert.h>
#include "pqueue.h"

//--------------- private utility functions ---------------
int _insert_pqueue_u(pQueue *pq, Data *d);
int _insert_pqueue_s(pQueue *pq, Data *d);
Data* _remove_pqueue_u(pQueue *pq);
Data* _remove_pqueue_s(pQueue *pq);
void _adjust_pqueue(pQueue *q);
int _find_top_priority(pQueue *q);

//----------------------------------------------------------------
pQueue* create_pqueue(int capacity, char priority, char type) {
	pQueue *q = (pQueue*) malloc(sizeof(pQueue));
	if (capacity < 1) {
		printf("Error(create_pqueue): invalid queue capacity, set to 10\n");
		capacity = 10;
	}
	if (priority != 'H' && priority != 'L') {
		printf("Error(create_pqueue): invalid priority, set to 'H'\n");
		priority = 'H';
	}
	q->capacity = capacity;
	q->_array = (Data**) malloc(sizeof(Data*) * capacity);
	q->_front = -1;
	q->_rear = -1;
	q->priority = priority;
	return q;
}
//----------------------------------------------------------------
int len_pqueue(pQueue *pq) {
	assert(pq);
	if (pq->_front == -1)
		return 0;
	return (pq->_rear - pq->_front + 1);
}
//----------------------------------------------------------------
int is_empty_pqueue(pQueue *pq) {
	assert(pq);
	return (len_pqueue(pq) == 0);
}
//----------------------------------------------------------------
int is_full_pqueue(pQueue *pq) {
	assert(pq);

	return (len_pqueue(pq) == pq->capacity);

}
//----------------------------------------------------------------
void _print_pqueue(pQueue *pq) {
	assert(pq);
	int i;
	if (pq->_type == 'u')
		printf("Priority Queue (unsorted insert, %c): ", pq->_type);
	else
		printf("Priority Queue (sorted insert, %c): ", pq->_type);
	printf("capacity = %d, size = %d, front = %d, rear = %d\n", pq->capacity,
			len_pqueue(pq), pq->_front, pq->_rear);
	if (is_empty_pqueue(pq))
		printf("<empty_pqueue>\n");
	else {
		int counter = 0;
		for (i = pq->_front; i <= pq->_rear; i++) {
			print_data(pq->_array[i]);
			if ((counter + 1) % 5 == 0 && counter != len_pqueue(pq) - 1)
				printf("\n");
			else
				printf("  ");
			counter++;
		}
		printf("\n");
	}
	return;
}
//----------------------------------------------------------------
int insert_pqueue(pQueue *pq, Data *d) {
	int result;
	if (is_full_pqueue(pq)) {
		printf("Error(insert_pqueue): pqueue is full\n");
		result = False;
	} else {
		if (pq->_type == 'u')
			result = _insert_pqueue_u(pq, d);
		else
			result = _insert_pqueue_s(pq, d);
	}
	return result;
}
//----------------------------------------------------------------
int _insert_pqueue_u(pQueue *pq, Data *d) {
	assert(pq && d);
	if (is_full_pqueue(pq)) {
		printf("Error(insert_pqueue_u): pqueue is full\n");
		return False;
	}
	if (is_empty_pqueue(pq)) {
		pq->_front = 0;
	} else if (pq->_rear == pq->capacity - 1)
		_adjust_pqueue(pq);
	pq->_rear++;
	pq->_array[pq->_rear] = copy_data(d);
	free(d);
	return (True);

}

//----------------------------------------------------------------
int _insert_pqueue_s(pQueue *pq, Data *d) {
	assert(pq && d);
	if (is_full_pqueue(pq)) {
		printf("Error(insert_pqueue_s): pqueue is full\n");
		return False;
	}
	if (is_empty_pqueue(pq)) {
		pq->_front = 0;
		pq->_rear = 0;
		pq->_array[pq->_rear] = copy_data(d);

	} else {
		int i, loc = -1;
		loc = insert_pqueue(pq, d);
		if (loc != -1) {
			for (i = pq->_rear; i >= loc; i--) {
				pq->_array[i + 1] = pq->_array[i];
			}
			pq->_array[loc] = copy_data(d);
			pq->_rear++;
		} else {
			pq->_array[pq->_rear + 1] = copy_data(d);
			pq->_rear++;
		}
		if (pq->_rear == pq->capacity && !is_full_pqueue(pq))
			_adjust_pqueue(pq);
	}
	return 1;
}
//----------------------------------------------------------------
void _adjust_pqueue(pQueue *pq) {
	assert(pq);
	int length = len_pqueue(pq), i;
	for (i = 0; i < length; i++) {
		pq->_array[i] = pq->_array[i + pq->_front];

	}
	pq->_front = 0;
	pq->_rear = length - 1;
	return;
}
//----------------------------------------------------------------
int _find_top_priority(pQueue *pq) {
	int i, loc = pq->_front;

	if (pq->priority == 'H') {
		for (i = pq->_front; i < pq->_rear + 1; i++) {
			if (compare_data(pq->_array[loc], pq->_array[i]) == 2) {
				loc = i;
			}

		}
	}

	else {
		for (i = pq->_front; i < pq->_rear + 1; i++) {
			if (compare_data(pq->_array[loc], pq->_array[i]) == 1) {

				loc = i;
			}
		}
	}
	return loc;

}
//----------------------------------------------------------------
Data* peek_pqueue(pQueue *pq) {
	assert(pq);
	if (is_empty_pqueue(pq)) {
		printf("Error(peek_pqueue): pqueue is empty\n");
		return NULL;
	}
	int loc;
	loc = _find_top_priority(pq);
	return copy_data(pq->_array[loc]);

}
//----------------------------------------------------------------
Data* remove_pqueue(pQueue *pq) {
	assert(pq);
	Data *result = NULL;
	if (is_empty_pqueue(pq))
		printf("Error(remove_pqueue): pqueue is empty\n");
	else {
		if (pq->_type == 'u')
			result = _remove_pqueue_u(pq);
		else
			result = _remove_pqueue_s(pq);
	}
	return result;
}
//----------------------------------------------------------------
Data* _remove_pqueue_u(pQueue *pq) {
	assert(pq);
	Data *d = NULL;

	if (is_empty_pqueue(pq)) {
		printf("Error(remove_pqueue_u): pqueue is empty\n");
		return NULL;
	}

	int i, loc = -1;
	loc = _find_top_priority(pq);
	d = copy_data(pq->_array[loc]);
	Data *temp = (pq->_array[loc]);
	destroy_data(temp);
	if (loc == pq->_front) {
		pq->_front++;
	} else if (loc == pq->_rear) {
		pq->_rear--;
	} else {
		for (i = loc; i < pq->_rear + 1; i++) {
			pq->_array[i] = pq->_array[i + 1];
		}
		pq->_rear--;

	}
	if (len_pqueue(pq) == 0) {
		pq->_front = -1;
		pq->_rear = -1;
	}

	return d;
}
//----------------------------------------------------------------
Data* _remove_pqueue_s(pQueue *pq) {
	assert(pq);
	Data *d = NULL;
	if (is_empty_pqueue(pq)) {
		printf("Error(remove_pqueue_s): pqueue is empty\n");
		return d;
	}
	d = copy_data(pq->_array[pq->_front]);
	Data *temp = (pq->_array[pq->_front]);
	destroy_data(temp);

	pq->_front++;

	if (len_pqueue(pq) == 0) {
		pq->_front = -1;
		pq->_rear = -1;
	}

	return d;
}
//----------------------------------------------------------------
void destroy_pqueue(pQueue **pq) {
	assert(pq && *pq);
	while (!is_empty_pqueue(*pq)) {
		Data *d = remove_pqueue(*pq);
		destroy_data(d);
	}

	free((*pq)->_array);
	(*pq)->_array = NULL;
	(*pq)->capacity = 0;
	(*pq)->_front = 0;
	(*pq)->_rear = 0;
	free(*pq);
	*pq = NULL;
	return;
}

