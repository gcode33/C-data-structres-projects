/*
 -------------------------------------
 File:    A9_test.c
 Project: A9
 file description
 -------------------------------------
 Author:  your name here
 ID:      your ID here
 Email:   your Laurier email here
 Version  2022-07-09
 -------------------------------------
 */

# include <stdio.h>
# include <stdlib.h>
# include "data.h"
# include "process.h"
# include "pqueue.h"

void test_pqueue(char mode, char type);

int main() {
	setbuf(stdout, NULL);
	test_pqueue('H', 'u'); //unsorted insert, priority = H
	test_pqueue('L', 'u'); //unsorted insert, priority = L
	test_pqueue('H', 's'); //sorted insert, priority = H
	test_pqueue('L', 's'); //sorted insert, priority = L
	return 0;
}

void test_pqueue(char mode, char type) {
	int size = 15;
	printf("------------------------------\n");
	printf("Start: Testing Priority Queue (priority = %c, type = %c):\n\n",
			mode, type);

	printf("Create an empty priority queue:\n");
	pQueue *pq = create_pqueue(10, mode, type);
	_print_pqueue(pq);
	printf("\n");

	printf("is_empty_pqueue(pq): ");
	printf("%d\n", is_empty_pqueue(pq));
	printf("is_full_pqueue(pq):");
	printf("%d\n", is_full_pqueue(pq));
	printf("peek_pqueue(pq): ");
	peek_pqueue(pq);
	printf("\n");

	Data **array = (Data**) malloc(sizeof(Data*) * size);

	int arrival = 10, service = 8, counter = 0, factor = -1;
	long pid = 1000100;
	printf("Creating an array of 15 data items:\n");
	for (int i = 0; i < 15; i++) {
		array[i] = create_process(pid++, arrival, service, 'R');
		print_data(array[i]);
		if (i % 2 == 1)
			printf("\n");
		else
			printf("  ");
		service = service % 4 + (i + 1) % 7;
		factor = factor * -1;
		arrival = (2 * (factor * i + 2)) - (factor * (arrival % 7));
		arrival = (arrival < 0) ? arrival * -1 : arrival;
	}
	printf("\n\n");

	printf("insert_pqueue: ");
	printf("success = %d\n", insert_pqueue(pq, array[counter++]));
	_print_pqueue(pq);
	printf("\n");

	printf("is_empty_pqueue(pq): ");
	printf("%d\n", is_empty_pqueue(pq));
	printf("is_full_pqueue(pq): ");
	printf("%d\n", is_full_pqueue(pq));
	printf("\n");

	printf("Adding 9 elements to pQueue:\n");
	int i;
	for (i = 0; i < 9; i++) {
		insert_pqueue(pq, array[counter++]);
		_print_pqueue(pq);
		printf("\n");
	}

	printf("is_full_pqueue(pq): %d\n\n", is_full_pqueue(pq));

	printf("insert_pqueue: ");
	printf("success = %d\n", insert_pqueue(pq, array[counter++]));
	_print_pqueue(pq);
	printf("\n");

	Data *temp;
	printf("peek_pqueue(pq): ");
	print_data(peek_pqueue(pq));
	printf("\n\n");

	printf("remove_pqueue(pq):\n");
	temp = remove_pqueue(pq);
	printf("removed data: ");
	print_data(temp);
	printf("\n");
	_print_pqueue(pq);
	printf("\n");

	printf("remove another element:\n");
	temp = remove_pqueue(pq);
	printf("removed data: ");
	print_data(temp);
	printf("\n");
	_print_pqueue(pq);
	printf("\n");

	printf("insert_pqueue:\n");
	insert_pqueue(pq, array[counter++]);
	_print_pqueue(pq);
	printf("\n");

	printf("remove 2 elements:\n");
	remove_pqueue(pq);
	_print_pqueue(pq);
	printf("\n");
	remove_pqueue(pq);
	_print_pqueue(pq);
	printf("\n");

	printf("Calling insert_pqueue 3 items:\n");
	for (i = 0; i < 3; i++) {
		insert_pqueue(pq, array[counter++]);
		_print_pqueue(pq);
		printf("\n");
	}

	printf("remove all elements\n");
	while (!is_empty_pqueue(pq)) {
		printf("peek: ");
		print_data(peek_pqueue(pq));
		printf(" , ");
		temp = remove_pqueue(pq);
		printf("removed data: ");
		print_data(temp);
		printf("\n");
		_print_pqueue(pq);
		printf("\n");
	}

	printf("destroy_pqueue(&pq): ");
	destroy_pqueue(&pq);
	if (!pq)
		printf("successful\n\n");

	for (i = 0; i < size; i++) {
		destroy_data(array[i]);
		array[i] = NULL;
	}

	printf("End: Testing Priority Queue (Priority = %c, type = %c):\n", mode,
			type);
	printf("------------------------------\n\n");
	return;
}
