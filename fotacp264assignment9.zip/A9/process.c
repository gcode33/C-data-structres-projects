/*
 -------------------------------------
 File:    Process.c
 Project: R7
 file description
 -------------------------------------
 Author:  your name here
 ID:      your ID here
 Email:   your Laurier email here
 Version  2022-06-13
 -------------------------------------
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include "process.h"
int _compare_process_S(Process *p1, Process *p2);
int _compare_process_AS(Process *p1, Process *p2);
Process* create_process(long p_pid, short p_arrival, short p_service, char p_pr) {
	Process *p = (Process*) malloc(sizeof(Process));

	p->PID = (p_pid <= 0) ? get_UPID() : p_pid;
	p->service = (p_service <= 0) ? 1 : p_service;
	p->arrival = (p_arrival <= 0) ? 0 : p_arrival;
	p->priority = (p_pr != 'R' && p_pr != 'H' && p_pr != 'L') ? 'R' : p_pr;

	return p;
}
//PID is 7 digitd starting at 1000100 up to 9999999
long get_UPID() {
	static short counter = 100;
	//get higher 4 digits
	//random number between 1000 to 9999
	long higher4 = rand() % (9999 - 1000 + 1) + 1000;

	//get lower 3 digits
	//sequental number between 100 to 999
	int lower3 = counter++;
	counter = (counter == 1000) ? 100 : counter;
	return higher4 + lower3;
}

void destroy_process(Process **p) {
	assert(*p);

	//rest all struct members
	(*p)->PID = 0;
	(*p)->service = 0;
	(*p)->arrival = 0;
	(*p)->priority = 0;

	//free dynamically created structurw
	free(*p);
	*p = NULL;
	return;
}
Process* copy_process(Process *p1) {
	assert(p1);
	//cant use p1 = p2 because its a shallow copy

	Process *p2 = (Process*) malloc(sizeof(Process));
	p2->PID = p1->PID;
	p2->service = p1->service;
	p2->arrival = p1->arrival;
	p2->priority = p1->priority;

	return p2;

}
void process_to_str(Process *p, char *str) {
	assert(p);
	char temp[30] = "";
	sprintf(temp, "[%hd](%ld,%hd)%c", p->arrival, p->PID, p->service,
			p->priority);
	strcpy(str, temp);
	return;
}

void print_process(Process *p) {
	assert(p);
	char str[30] = "";
	process_to_str(p, str);
	printf("%s", str);
	return;
	return;
}
int compare_process(Process *p1, Process *p2, char *mode) {
	assert(p1 && p2);
	int result = -1;
	if (strcmp(mode, "S") == 0)
		result = _compare_process_S(p1, p2);
	else if (strcmp(mode, "AS") == 0)
		result = _compare_process_AS(p1, p2);
	else
		printf("error(compare_process) undefinde mode\n");
	return result;
}
int _compare_process_S(Process *p1, Process *p2) {
	assert(p1 && p2);
	int result;
	if (p1->service > p2->service)
		result = -1;
	else if (p1->service < p2->service)
		result = 2;
	else
		result = 0;
	return result;
}
int _compare_process_AS(Process *p1, Process *p2) {
	assert(p1 && p2);
	int result;
	if (p1->arrival > p2->arrival)
		result = -1;
	else if (p1->arrival < p2->arrival)
		result = 2;
	else
		//equal arrival
		result = _compare_process_S(p1, p2);

	return result;
}
