/*
 -------------------------------------
 File:    A9.h
 Project: A9
 file description
 -------------------------------------
 Author:  your name here
 ID:      your ID here
 Email:   your Laurier email here
 Version  2022-07-09
 -------------------------------------
 */
#ifndef PQUEUE_H_
#define PQUEUE_H_

# include "data.h"

# define True 1
# define False 0
# define DEFAULT_PQUEUE_CAPACITY 10

typedef struct {
	int capacity;	//maximum queue length
	Data **_array; 	//array containing data items
	int _front;		//index of first item in Queue
	int _rear;		//index of last item in Queue
	char priority;  //'H' = Higher priority first, 'L' = Lower priority first
	char _type;		//'s' = sorted insertion, 'u' = unsorted insertion
} pQueue;

pQueue* create_pqueue(int capacity, char priority, char type);
int is_empty_pqueue(pQueue *q);
int len_pqueue(pQueue *q);
int is_full_pqueue(pQueue *q);
void destroy_pqueue(pQueue **q);
void _print_pqueue(pQueue *q);
int insert_pqueue(pQueue *q, Data *d);
Data* peek_pqueue(pQueue *q);
Data* remove_pqueue(pQueue *q);

#endif /* PQUEUE_H_ */

