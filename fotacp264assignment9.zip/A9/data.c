/*
 -------------------------------------
 File:    data.c
 Project: R7
 file description
 -------------------------------------
 Author:  your name here
 ID:      your ID here
 Email:   your Laurier email here
 Version  2022-06-13
 -------------------------------------
 */
#include <stdio.h>
#include <assert.h>
#include "data.h"

void print_data(Data *d) {
	print_process(d);
	return;
}
void destroy_data(Data *d) {
	destroy_process(&d);
	return;
}
Data* copy_data(Data *d) {
	return copy_process(d);
}
int compare_data(Data *d1, Data *d2) {
	return compare_process(d1, d2, "AS");
}

