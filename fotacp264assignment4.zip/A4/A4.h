/*
 -------------------------------------
 File:    A4.h
 Project: A4
 file description
 -------------------------------------
 Author:  your name here
 ID:      your ID here
 Email:   your Laurier email here
 Version  2022-06-04
 -------------------------------------
 */

#ifndef A4_H_
#define A4_H_

# define MAX 13
# define STRING_MAX 20
# define NUM 10

void reverse_void_array(void*, const int, char);
void analyze_ptr_array(short*, short*[]);
int is_phone(char*);
int is_fphone(char*);
void format_phone_number(char*);
void format_phone_list(char[][STRING_MAX], const int size);
short* create_2d_array1(short*, const int);
void print_2d_array1(short*, const int);
long** create_2d_array2(long*, const int);
void print_2d_array2(long **array, const int size);

#endif /* A4_H_ */
