/*
 -------------------------------------
 File:    A4.c
 Project: A4
 file description
 -------------------------------------
 Author:  your name here
 ID:      your ID here
 Email:   your Laurier email here
 Version  2022-06-04
 -------------------------------------
 */
//put your include statements here
#include <stdio.h>
#include "A4.h"
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <stdbool.h>

//---------------- Task 1 ---------------------------
void analyze_ptr_array(short *array, short *ptrs[]) {
	int i = 0;
	short *temp = array;
	for (short i = 0; i < MAX; i++)
		if (temp == *ptrs)
			temp++;

	while (ptrs[i] != NULL) {
		short index = *ptrs[i];
		printf("Index is: %d\n", index);
		printf("Value is: %d\n", *ptrs[i]);
		printf("Previous element value is: %d\n",
				index == 0 ? -1 : *(ptrs[i] - 1));
		printf("Next element value is: %d\n",
				index == MAX ? -1 : *(ptrs[i] + 1));
		printf("\n");
		i++;
	}
	return;
}

//---------------- Task 2 ---------------------------
void reverse_void_array(void *array, const int size, char mode) {
	//put your code here
	if (array == NULL) {
		printf("error(find_index_array): array is NULL\n");
	}
	if (size <= 0) {
		printf("error(find_index_array): invalid size\n");
	}
	int i, temp1 = 0;
	char temp2;
	int len = strlen(array);
	int h = len - 1;
	int j = 0;
	char *s2 = (char*) malloc(sizeof(char) * (len + 1));
	int *s1 = (int*) malloc(sizeof(int) * (size + 1));
	strcpy(s2, array);
	if (mode == 'i') {
		for (i = 0; i < (size / 2); i++) {
			temp1 = s1[i];
			s1[i] = s1[size - i - 1];
			s1[size - i - 1] = temp1;
		}
	} else if (mode == 'h') {
		while (h > j) {
			temp2 = s2[h];
			s2[h--] = s2[j];
			s2[j++] = temp2;
		}

	} else {
		printf("Error(reserve_void_array): unsupported mode\n");
	}
	return;
}

//---------------- Task 3 ---------------------------
int is_phone(char *phone) {
	//put your code here
	int size = strlen(phone);
	for (int i = 0; i < size; i++) {
		if (!isdigit(phone[i]) && size != 10) {
			return false;
		} else {
			return true;
		}
	}
	return 0;
}

int is_fphone(char *phone) {
	//put your code here
	int size = strlen(phone);
	for (int i = 0; i < size; i++) {
		if (phone[0] != '(' && phone[4] != ')' && phone[8] != '-') {
			return false;
		} else if (size < 12) {
			return false;
		} else if (!isdigit(phone[1]) || !isdigit(phone[2])
				|| !isdigit(phone[3]) || !isdigit(phone[5])
				|| !isdigit(phone[6]) || !isdigit(phone[7])
				|| !isdigit(phone[9]) || !isdigit(phone[10])) {
			return false;

		} else {
			return true;
		}
	}
	return 0;
}
void format_phone_number(char *num) {
	//put your code here
	return;
}

void format_phone_list(char list[][STRING_MAX], const int size) {
	//put your code here
	return;
}

//---------------- Task 4 ---------------------------
//Guide: https://www.geeksforgeeks.org/dynamically-allocate-2d-array-c/
short* create_2d_array1(short *nums, const int size) {
	if (size <= 0) {
		printf("Error(create_2d_array1): invalid size\n");
		return NULL;
	}
	if (!nums) {
		printf("Error(create_2d_array1): invalid size\n");
		return NULL;
	}
	short *array = (short*) malloc(10 * size * sizeof(short));
	short i, j;
	for (i = 0; i < size; i++)
		for (j = 0; j < 10; j++) {

			if (nums[i] * (j + 1) >= 1000)
				*(array + i * 10 + j) = 0;
			else
				*(array + i * 10 + j) = (nums[i] * (j + 1));
		}

	return array;
}

void print_2d_array1(short *array, const int size) {
	if (size <= 0) {
		printf("Error(print_2d_array1): invalid size\n");
		return;
	}
	if (!array) {
		printf("Error(print_2d_array1): invalid size\n");
		return;
	}
	short i, j;
	for (i = 0; i < size; i++) {
		for (j = 0; j < 10; j++) {
			printf("%3hu", *(array + i * 10 + j));
			if (j < 9)
				printf(" ");
		}
		printf("\n");
	}

	return;
}

//---------------- Task 5 ---------------------------
long** create_2d_array2(long *nums, const int size) {
	if (size <= 0) {
		printf("Error(create_2d_array2): invalid size\n");
		return NULL;
	}
	if (!nums) {
		printf("Error(create_2d_array2): invalid size\n");
		return NULL;
	}
	long i, j;
	long **arr = (long**) malloc(size * sizeof(long*));
	for (i = 0; i < size; i++)
		arr[i] = (long*) malloc(10 * sizeof(long));

	for (i = 0; i < size; i++) {
		for (j = 0; j < 10; j++) {

			if (nums[i] * (j + 1) >= 1000)
				arr[i][j] = 0;
			else

				arr[i][j] = nums[i] * (j + 1);

		}
	}
	return arr;
}

void print_2d_array2(long **array, const int size) {
	if (!array) {
		printf("Error(print_2d_array2): invalid size\n");
		return;
	}
	if (size <= 0) {
		printf("Error(print_2d_array2): invalid size\n");
		return;
	}
	long i, j;
	for (i = 0; i < size; i++) {
		for (j = 0; j < 10; j++) {
			printf("%3ld", (array[i][j]));
			if (j < 9)
				printf(" ");
		}
		printf("\n");
	}

	return;
}
