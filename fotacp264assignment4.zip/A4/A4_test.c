/*
 -------------------------------------
 File:    A4_test.c
 Project: A4
 file description
 -------------------------------------
 Author:  your name here
 ID:      your ID here
 Email:   your Laurier email here
 Version  2022-06-04
 -------------------------------------
 */

# include <stdio.h>
# include <stdlib.h>
# include <string.h>
# include "A4.h"

void test_analyze_ptr_array();
void test_reverse_void_array();
void print_array(void*, const int, char);
void test_is_phone();
void test_is_fphone();
void test_format_phone_number();
void test_format_phone_list();
void test_2d_array1();
void test_2d_array2();

int main() {
	setbuf(stdout, NULL);
	test_analyze_ptr_array();
	test_reverse_void_array();
	test_is_phone();
	test_is_fphone();
	test_format_phone_number();
	test_format_phone_list();
	test_2d_array1();
	test_2d_array2();
	return 0;
}

void test_reverse_void_array() {
	printf("------------------------------\n");
	printf("Start: Testing reverse_void_array:\n\n");

	printf("Case 1: mode i\n");
	int array1[5] = { 10, 20, 30, 40, 50 };
	printf("Before reverse:");
	print_array(array1, 5, 'I');
	reverse_void_array(array1, 5, 'i');
	printf("After reverse: ");
	print_array(array1, 5, 'I');
	printf("\n");

	printf("Case 2: mode h\n");
	short array2[7] = { 10, 20, 30, 40, 50, 60, 70 };
	printf("Before reverse:");
	print_array(array2, 7, 'H');
	reverse_void_array(array2, 7, 'h');
	printf("After reverse: ");
	print_array(array2, 7, 'H');
	printf("\n");

	printf("Case 3: error cases\n");
	reverse_void_array(NULL, 7, 'h');
	reverse_void_array(array2, -1, 'h');
	reverse_void_array(array2, 7, 'd');
	printf("\n");

	printf("End: Testing reverse_void_array\n");
	printf("------------------------------\n\n");
	return;
}
void test_analyze_ptr_array() {
	printf("------------------------------\n");
	printf("Start: Testing analyze_ptr_array:\n\n");

	short *ptrs[MAX];

	printf("Case 1:\n");
	short array1[MAX] = { 10, 5, 20, 17, 30, 42, 50, 33, 60, 79, 91, 46, 9 };
	printf("Array is: ");
	print_array(array1, MAX, 'H');
	printf("Calling analyze_ptr_array: \n");
	ptrs[0] = &array1[1];
	ptrs[1] = &array1[4];
	ptrs[2] = &array1[8];
	ptrs[3] = NULL;
	analyze_ptr_array(array1, ptrs);
	printf("\n");

	printf("Case 2:\n");
	printf("Array is: ");
	print_array(array1, MAX, 'H');
	ptrs[0] = &array1[0];
	ptrs[1] = &array1[4];
	ptrs[2] = NULL;
	printf("Calling analyze_ptr_array: \n");
	analyze_ptr_array(array1, ptrs);
	printf("\n");

	short array2[MAX] = { 6, 2, 3, 1, 5, 12, 1, 11, 8, 0, 9, 4, 7 };
	printf("Case 3:\n");
	printf("Array is: ");
	print_array(array2, MAX, 'H');
	ptrs[0] = &array2[1];
	ptrs[1] = &array2[3];
	ptrs[2] = &array2[6];
	ptrs[3] = &array2[9];
	ptrs[4] = &array2[12];
	ptrs[5] = NULL;
	printf("Calling analyze_ptr_array: \n");
	analyze_ptr_array(array2, ptrs);
	printf("\n");

	printf("Case 4:\n");
	printf("Array is: ");
	print_array(array2, MAX, 'H');
	ptrs[0] = NULL;
	printf("Calling analyze_ptr_array: \n");
	analyze_ptr_array(array2, ptrs);
	printf("\n");

	printf("Case 5:\n");
	printf("Array is: NULL\n");
	printf("Calling analyze_ptr_array: \n");
	analyze_ptr_array(NULL, ptrs);
	printf("\n");

	printf("End: Testing analyze_ptr_array\n");
	printf("------------------------------\n\n");
	return;
}

void test_is_phone() {
	printf("------------------------------\n");
	printf("Start: Testing is_phone:\n\n");

	char phonelist[][STRING_MAX] = { "4561123344", "567567992", "77711199990",
			"56756799g2" };
	for (int i = 0; i < 4; i++)
		printf("%s --> %d\n", phonelist[i], is_phone(phonelist[i]));
	printf("NULL --> %d\n\n", is_phone(NULL));

	printf("End: Testing is_phone\n");
	printf("------------------------------\n\n");
	return;
}

void test_is_fphone() {
	printf("------------------------------\n");
	printf("Start: Testing is_fphone:\n\n");

	char phonelist[][STRING_MAX] = { "(456)112-3344", "(567) 567-9922",
			"7771119999", "[456]112-3344", "(406)157 3384", "(502)157-a384" };
	for (int i = 0; i < 6; i++)
		printf("%s --> %d\n", phonelist[i], is_fphone(phonelist[i]));
	printf("NULL --> %d\n\n", is_fphone(NULL));

	printf("End: Testing is_phone\n");
	printf("------------------------------\n\n");
	return;
}

void test_format_phone_number() {
	printf("------------------------------\n");
	printf("Start: Testing format_phone_number:\n\n");

	char phone1[STRING_MAX];
	printf("Case 1: non-formatted number\n");
	strcpy(phone1, "4317562221");
	printf("Before: %s\n", phone1);
	format_phone_number(phone1);
	printf("After:  %s\n\n", phone1);

	printf("Case 2: formatted number\n");
	strcpy(phone1, "(401)611-5892");
	printf("Before: %s\n", phone1);
	format_phone_number(phone1);
	printf("After:  %s\n\n", phone1);

	printf("Case 3: invalid numbers\n");
	strcpy(phone1, "321b620121");
	printf("Before: %s , ", phone1);
	format_phone_number(phone1);
	printf("After: %s\n", phone1);
	strcpy(phone1, "[401]611-5890");
	printf("Before: %s , ", phone1);
	format_phone_number(phone1);
	printf("After: %s\n", phone1);
	format_phone_number(NULL);
	printf("\n");

	printf("End: Testing format_phone_number\n");
	printf("------------------------------\n\n");
	return;
}

void test_format_phone_list() {
	printf("------------------------------\n");
	printf("Start: Testing format_phone_list:\n\n");

	printf("Case 1: (3 valid non-formatted numbers):\n");
	char phonelist[][STRING_MAX] = { "4561123344", "6664442222", "7771119999",
			"5675679922", "7879926531" };
	printf("{%s, %s, %s}\n", phonelist[0], phonelist[1], phonelist[2]);
	format_phone_list(phonelist, 5);
	printf("{%s, %s, %s}\n\n", phonelist[0], phonelist[1], phonelist[2]);

	printf("Case 2: (mix of valid formatted and non-formatted numbers)\n");
	strcpy(phonelist[1], "6664442222");
	strcpy(phonelist[2], "7771119999");
	printf("{%s, %s, %s, %s, %s}\n", phonelist[0], phonelist[1], phonelist[2],
			phonelist[3], phonelist[4]);
	format_phone_list(phonelist, 5);
	printf("{%s, %s, %s, %s, %s}\n\n", phonelist[0], phonelist[1], phonelist[2],
			phonelist[3], phonelist[4]);

	printf("Case 3: (invalid phone numbers)\n");
	strcpy(phonelist[0], "66a4442222");
	strcpy(phonelist[1], "77711199990");
	strcpy(phonelist[2], "(777)111*9999");
	strcpy(phonelist[3], "(###)###-####");
	printf("{%s, %s, %s, %s}\n", phonelist[0], phonelist[1], phonelist[2],
			phonelist[3]);
	format_phone_list(phonelist, 4);
	printf("{%s, %s, %s, %s}\n\n", phonelist[0], phonelist[1], phonelist[2],
			phonelist[3]);

	printf("Case 4: (mix of valid and invalid numbers):\n");
	strcpy(phonelist[0], "6664442222");
	printf("{%s, %s}\n", phonelist[0], phonelist[1]);
	format_phone_list(phonelist, 2);
	printf("{%s, %s}\n\n", phonelist[0], phonelist[1]);

	printf("Case 5: invalid cases:\n");
	format_phone_list(phonelist, 0);
	format_phone_list(NULL, 1);
	printf("\n");

	printf("End: Testing format_phone_list\n");
	printf("------------------------------\n\n");
	return;
}

void print_array(void *arrayPtr, const int size, char mode) {
	int i;
	if (size <= 0)
		printf("{ }\n");
	else
		switch (mode) {
		case 'C':
			printf("\"%s\"\n", (char*) arrayPtr);
			break;
		case 'H':
			printf("{ ");
			for (i = 0; i < size - 1; i++) {
				printf("%hd , ", *(short*) arrayPtr);
				arrayPtr = arrayPtr + sizeof(short);
			}
			printf("%hd }\n", *(short*) arrayPtr);
			break;
		case 'I':
			printf("{ ");
			for (i = 0; i < size - 1; i++) {
				printf("%d , ", *(int*) arrayPtr);
				arrayPtr = arrayPtr + sizeof(int);
			}
			printf("%d }\n", *(int*) arrayPtr);
			break;
		case 'D':
			printf("{ ");
			for (i = 0; i < size - 1; i++) {
				printf("%.3lf , ", *(double*) arrayPtr);
				arrayPtr = arrayPtr + sizeof(double);
			}
			printf("%.3lf }\n", *(double*) arrayPtr);
			break;
		default:
			printf("Error(print_array): unsupported mode\n");
		}
	return;
}

void test_2d_array1() {
	printf("------------------------------\n");
	printf("Start: Testing 2d_array1:\n\n");

	short nums1[3] = { 12, 15, 220 };
	short *ptr = NULL;
	ptr = create_2d_array1(nums1, 3);
	print_2d_array1(ptr, 3);
	free(ptr);
	ptr = NULL;
	printf("\n");

	short nums2[5] = { 5, 17, 27, 46, 59 };
	ptr = create_2d_array1(nums2, 5);
	print_2d_array1(ptr, 5);
	free(ptr);
	ptr = NULL;
	printf("\n");

	short nums3[1] = { 199 };
	ptr = create_2d_array1(nums3, 1);
	print_2d_array1(ptr, 1);
	free(ptr);
	ptr = NULL;
	printf("\n");

	ptr = create_2d_array1(NULL, 6);
	print_2d_array1(ptr, 6);
	printf("\n");

	short nums4[2] = { 1, 2 };
	ptr = create_2d_array1(nums4, 0);
	print_2d_array1(nums4, 0);
	printf("\n");

	printf("End: Testing 2d_array1\n");
	printf("------------------------------\n\n");
	return;
}

void test_2d_array2() {
	printf("------------------------------\n");
	printf("Start: Testing 2d_array2:\n\n");

	long nums1[3] = { 12, 15, 220 };
	long **ptr = NULL;
	ptr = create_2d_array2(nums1, 3);
	print_2d_array2(ptr, 3);
	for (int i = 0; i < 3; i++)
		free(ptr[i]);
	free(ptr);
	ptr = NULL;
	printf("\n");

	long nums2[5] = { 3, 14, 25, 36, 47 };
	ptr = create_2d_array2(nums2, 5);
	print_2d_array2(ptr, 5);
	for (int i = 0; i < 5; i++)
		free(ptr[i]);
	free(ptr);
	ptr = NULL;
	printf("\n");

	long nums3[1] = { 299 };
	ptr = create_2d_array2(nums3, 1);
	print_2d_array2(ptr, 1);
	for (int i = 0; i < 1; i++)
		free(ptr[i]);
	free(ptr);
	ptr = NULL;
	printf("\n");

	ptr = create_2d_array2(NULL, 6);
	print_2d_array2(ptr, 6);
	printf("\n");

	long nums4[2] = { 1, 2 };
	long *ptr1 = &nums4[0], **ptr2 = &ptr1;
	ptr2 = create_2d_array2(ptr1, 0);
	ptr2 = create_2d_array2(ptr1, 4);
	print_2d_array2(ptr2, 0);
	printf("\n");

	printf("End: Testing 2d_array2\n");
	printf("------------------------------\n\n");
	return;

}

