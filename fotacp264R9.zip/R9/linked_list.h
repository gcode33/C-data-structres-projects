/*
 -------------------------------------
 File:    linked_list.h
 Project: R9
 file description
 -------------------------------------
 Author:  your name here
 ID:      your ID here
 Email:   your Laurier email here
 Version  2022-06-27
 -------------------------------------
 */

#ifndef LINKED_LIST_H_
#define LINKED_LIST_H_

#include "node.h"

typedef struct {
	Node *head;
	int size;
} Linked_List;

Linked_List* create_linked_list();
int is_empty_linked_list(Linked_List*);
void print_linked_list(Linked_List*);
void append_linked_list(Linked_List*, Data *d);
int insert_linked_list(Linked_List*, Data *d, int);
void destroy_linked_list(Linked_List**);
Data* remove_linked_list(Linked_List*, int);
void reverse_linked_list(Linked_List *List);
Data* get_item_linked_list(Linked_List *List, int index);
void swap_items_linked_list(Linked_List*, int, int);

#endif /* LINKED_LIST_H_ */
