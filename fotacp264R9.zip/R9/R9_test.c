/*
 -------------------------------------
 File:    R9_test.c
 Project: R9
 file description
 -------------------------------------
 Author:  your name here
 ID:      your ID here
 Email:   your Laurier email here
 Version  2022-06-27
 -------------------------------------
 */

# include <stdio.h>
# include <stdlib.h>
# include "linked_list.h"

void test_node();
void test_basic_linked_list();
void test_insert_remove();
void test_get_item();
void test_reverse();
void test_swap();

int main() {
	setbuf(stdout, NULL);
	test_node();
	test_basic_linked_list();
	test_insert_remove();
	test_get_item();
	test_reverse();
	test_swap();
	return 0;
}

void test_node() {
	printf("------------------------------\n");
	printf("Start: Testing Linked List Node:\n\n");

	short service = 10, arrival = 1;
	long pid = 1000100;

	Data *d = create_process(pid++, arrival++, service++, 'R');
	printf("Create process ");
	print_process(d);
	printf("\n");
	printf("Create a node with the above process\n");
	Node *n1 = create_node(d, NULL);
	printf("Print node: ");
	print_node(n1);
	printf("\n\n");

	printf("Create another node:\n");
	Node *n2 = create_node(create_process(pid++, arrival++, service++, 'R'),
	NULL);
	print_node(n2);
	printf("\n\n");
	printf("link two nodes together:\n");
	n1->next = n2;
	printf("Print node 2 through node 1:\n");
	print_node(n1->next);
	printf("\n\n");

	printf("Copy Node 1 to node 3:\n");
	Node *n3 = copy_node(n1);
	printf("Print node 3:\n");
	print_node(n3);
	printf("\n");
	printf("Print node 2 through node 3:\n");
	print_node(n3->next);
	printf("\n\n");

	printf("Destroy node 1\n");
	destroy_node(&n1);
	destroy_data(d);
	printf("Destroy node 2\n");
	d = n2->data;
	destroy_node(&n2);
	destroy_data(d);
	printf("Destroy node 3\n");
	d = n3->data;
	destroy_node(&n3);
	destroy_data(d);
	printf("\n");

	printf("End: Testing Linked List Node\n");
	printf("------------------------------\n\n");
	return;
}

void test_basic_linked_list() {
	//test create, destroy, append print and is_empty
	printf("------------------------------\n");
	printf("Start: Testing Linked List basic functions:\n\n");

	short service = 10, arrival = 1;
	long pid = 1000100;

	printf("Create an empty list: ");
	Linked_List *list = create_linked_list();
	if (list)
		printf("successful\n");
	else
		printf("failed\n");
	printf("Printing linked list:\n");
	print_linked_list(list);
	printf("\n");
	printf("is_empty_linked_list? --> %d\n\n", is_empty_linked_list(list));

	printf("Appending to an empty linked list\n");
	Data *d1 = create_process(pid++, arrival++, service++, 'R');
	append_linked_list(list, d1);
	print_linked_list(list);
	printf("\n");

	printf("is_empty_linked_list? --> %d\n\n", is_empty_linked_list(list));

	printf("Appending second element\n");
	Data *d2 = create_process(pid++, arrival++, service++, 'R');
	append_linked_list(list, d2);
	print_linked_list(list);
	printf("\n");

	printf("Appending third element\n");
	Data *d3 = create_process(pid++, arrival++, service++, 'R');
	append_linked_list(list, d3);
	print_linked_list(list);
	printf("\n");

	printf("destroy linked list\n");
	destroy_linked_list(&list);

	destroy_data(d1);
	destroy_data(d2);
	destroy_data(d3);
	printf("destroy data successful\n");
	printf("\n");

	printf("End: Testing Linked List basic functions\n");
	printf("------------------------------\n\n");
	return;
}

void test_insert_remove() {
	printf("------------------------------\n");
	printf("Start: Testing Linked List insert and remove:\n\n");

	short service = 10, arrival = 1;
	long pid = 1000100;

	Data *d[7];
	int i;
	for (i = 0; i < 7; i++)
		d[i] = create_process(pid++, arrival++, service++, 'R');

	printf("Create an empty list: ");
	Linked_List *list = create_linked_list();
	print_linked_list(list);

	int index1[7] = { 0, 1, 0, 1, 2, 5, 7 };
	for (i = 0; i < 7; i++) {
		printf("insert at %d:\n", index1[i]);
		insert_linked_list(list, d[i], index1[i]);
		print_linked_list(list);
		printf("\n");
	}

	int index2[7] = { 0, 1, 2, 2, 1, 6, 0 };
	for (i = 0; i < 7; i++) {
		printf("remove %d:\n", index2[i]);
		remove_linked_list(list, index2[i]);
		print_linked_list(list);
		printf("\n");
	}

	destroy_linked_list(&list);
	if (!list)
		printf("linked list destroyed successfully\n");
	for (i = 0; i < 7; i++)
		destroy_data(d[i]);
	printf("data items destroyed successfully\n\n");

	printf("End: Testing Linked List insert and remove\n");
	printf("------------------------------\n\n");
	return;
}

void test_get_item() {
	printf("------------------------------\n");
	printf("Start: Testing get_item_linked_list:\n\n");

	short service = 10, arrival = 1;
	long pid = 1000100;

	Data *d[10];
	int i;
	for (i = 0; i < 10; i++)
		d[i] = create_process(pid++, arrival++, service++, 'R');

	printf("Case 1: An Empty List\n");
	Linked_List *list = create_linked_list();
	print_linked_list(list);
	printf("\n");

	printf("Get item 0:\n");
	get_item_linked_list(list, 0);
	printf("\n\n");

	printf("Inserting 10 items\n");
	for (i = 0; i < 10; i++)
		append_linked_list(list, d[i]);
	print_linked_list(list);
	printf("\n");

	printf("Get item 0:\n");
	print_data(get_item_linked_list(list, 0));
	printf("\n\n");

	printf("Get item 3:\n");
	print_data(get_item_linked_list(list, 3));
	printf("\n\n");

	printf("Get item 9:\n");
	print_data(get_item_linked_list(list, 9));
	printf("\n\n");

	printf("Get item 10:\n");
	if (get_item_linked_list(list, 10) == NULL)
		printf("NULL\n");
	printf("\n");

	destroy_linked_list(&list);
	if (!list)
		printf("linked list destroyed successfully\n");
	for (i = 0; i < 7; i++)
		destroy_data(d[i]);
	printf("data items destroyed successfully\n\n");

	printf("End: Testing get_item_linked_list\n");
	printf("------------------------------\n\n");
}

void test_reverse() {
	printf("------------------------------\n");
	printf("Start: Testing List reverse function:\n\n");

	short service = 10, arrival = 1;
	long pid = 1000100;

	Data *d[10];
	int i;
	for (i = 0; i < 10; i++)
		d[i] = create_process(pid++, arrival++, service++, 'R');

	printf("Case 1: An Empty List\n");
	Linked_List *list = create_linked_list();
	print_linked_list(list);
	printf("After calling reverse function:\n");
	reverse_linked_list(list);
	print_linked_list(list);
	printf("\n");

	printf("Case 2: Single item List\n");
	append_linked_list(list, d[0]);
	print_linked_list(list);
	printf("After calling reverse function:\n");
	reverse_linked_list(list);
	print_linked_list(list);
	printf("\n");

	printf("Case 2: List with two items\n");
	append_linked_list(list, d[1]);
	print_linked_list(list);
	printf("After calling reverse function:\n");
	reverse_linked_list(list);
	print_linked_list(list);
	printf("\n");

	reverse_linked_list(list); //restore original order

	printf("Case 3: List with 10 items\n");
	for (i = 2; i < 10; i++)
		append_linked_list(list, d[i]);
	print_linked_list(list);
	printf("After calling reverse function:\n");
	reverse_linked_list(list);
	print_linked_list(list);
	printf("\n");

	printf("destroy linked list\n");
	destroy_linked_list(&list);
	for (i = 0; i < 7; i++)
		destroy_data(d[i]);
	printf("data items destroyed successfully\n\n");

	printf("End: Testing List reverse function\n");
	printf("------------------------------\n\n");
	return;
}

void test_swap() {
	printf("------------------------------\n");
	printf("Start: Testing swap_items_linked_list:\n\n");

	short service = 10, arrival = 1;
	long pid = 1000100;

	Data *d[10];
	int i;
	for (i = 0; i < 10; i++)
		d[i] = create_process(pid++, arrival++, service++, 'R');

	Linked_List *list = create_linked_list();
	print_linked_list(list);
	printf("swap_list(list,1,2):\n");
	swap_items_linked_list(list, 1, 2);
	printf("\n");

	printf("Create a linked list with 10 processes:\n");
	for (i = 0; i < 10; i++)
		append_linked_list(list, d[i]);
	print_linked_list(list);
	printf("\n");

	printf("swap_list(list,-1,5):\n");
	swap_items_linked_list(list, -1, 5);
	print_linked_list(list);
	printf("\n");

	printf("swap_list(list,2,2):\n");
	swap_items_linked_list(list, 2, 2);
	print_linked_list(list);
	printf("\n");

	printf("swap_list(list,1,2):\n");
	swap_items_linked_list(list, 1, 2);
	print_linked_list(list);
	printf("\n");

	printf("swap_list(list,1,3):\n");
	swap_items_linked_list(list, 1, 3);
	print_linked_list(list);
	printf("\n");

	printf("swap_list(list,0,1):\n");
	swap_items_linked_list(list, 0, 1);
	print_linked_list(list);
	printf("\n");

	printf("swap_list(list,0,5):\n");
	swap_items_linked_list(list, 0, 5);
	print_linked_list(list);
	printf("\n");

	printf("swap_list(list,6,9):\n");
	swap_items_linked_list(list, 6, 9);
	print_linked_list(list);
	printf("\n");

	printf("swap_list(list,8,9):\n");
	swap_items_linked_list(list, 8, 9);
	print_linked_list(list);
	printf("\n");

	printf("destroy linked list\n");
	destroy_linked_list(&list);
	for (i = 0; i < 7; i++)
		destroy_data(d[i]);
	printf("data items destroyed successfully\n\n");

	printf("End: Testing List swap_items_linked_list\n");
	printf("------------------------------\n\n");
	return;
}

