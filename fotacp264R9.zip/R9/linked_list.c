/*
 -------------------------------------
 File:    linked_list.c
 Project: R9
 file description
 -------------------------------------
 Author:  your name here
 ID:      your ID here
 Email:   your Laurier email here
 Version  2022-06-27
 -------------------------------------
 */

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "Linked_list.h"

Linked_List* create_linked_list() {
	Linked_List *list = (Linked_List*) malloc(sizeof(Linked_List));
	list->head = NULL;
	list->size = 0;
	return list;
}
int is_empty_linked_list(Linked_List *List) {
	assert(List);
	return (List->head == NULL);
}
void print_linked_list(Linked_List *List) {
	assert(List);
	Node *current_node = List->head;
	while (current_node != NULL) {
		print_node(current_node);
		printf("-->");
		current_node = current_node->next;
	}
	printf("NULL\n");
	return;
}
void append_linked_list(Linked_List *List, Data *d) {
	Node *new_node = create_node(d, NULL);
	if (is_empty_linked_list(List))
		List->head = new_node;
	else {
		Node *current_node = List->head;
		while (current_node->next != NULL)
			current_node = current_node->next;
		current_node->next = new_node;
	}
	List->size++;
	return;
}
int insert_linked_list(Linked_List *List, Data *d, int index) {
	assert(List && d);
	//case 0 invalid index
	if (index < 0 || index > List->size) {
		printf("Error(Insert_Linked_List): index out of range\n");
		return 0;
	}
	Node *new_node = create_node(d, NULL);
	//case 1 inserting at the head
	if (index == 0) {
		if (!is_empty_linked_list(List))
			new_node->next = List->head;
		List->head = new_node;
	}
	//case 2: inserting anywhere after the head
	else {
		int i = 0;
		Node *current_node = List->head;
		while (i++ < index - 1)
			current_node = current_node->next;
		new_node->next = current_node->next;
		current_node->next = new_node;
	}
	List->size++;
	return 1;
}

void destroy_linked_list(Linked_List **List) {
	assert(List && *List);
	while (!is_empty_linked_list(*List))
		remove_linked_list(*List, 0);
	(*List)->head = NULL;
	(*List)->size = 0;
	free(*List);
	*List = NULL;
	return;
}

Data* remove_linked_list(Linked_List *List, int index) {
	assert(List);
	int size = List->size;
	Data *item = NULL;
	//case 0 empty Linked list
	if (is_empty_linked_list(List)) {
		printf("Error(remove_linked_list): empty linked list\n");
		return NULL;
	}
	//case 1 index out of range
	if (index < 0 || index >= size) {
		printf("Error(remove_linked_list): index out of range\n");
		return NULL;
	}
	Node *del_node;
	//case 2 remove first node
	if (index == 0) {
		del_node = List->head;
		List->head = List->head->next;
	}
	//case3 remove any other node
	else {
		Node *current_node = List->head;
		Node *previous_node = NULL;
		int i = 0;
		while (current_node->next && i < index) {
			previous_node = current_node;
			current_node = current_node->next;
			i++;
		}
		previous_node->next = current_node->next;
		del_node = current_node;
	}
	List->size--;
	item = del_node->data;
	destroy_node(&del_node);
	return item;
}

void reverse_linked_list(Linked_List *List) {
	assert(List);
	if (List->size <= 1)
		return;

	//initialize prev, curr and next node pointer
	Node *previous_node = NULL;
	Node *current_node = List->head;
	Node *next_node = current_node->next;

	//loop to reverse a limk at 0 time
	while (next_node) {
		current_node->next = previous_node; //reverse the link
		//update the pointers for next node
		previous_node = current_node;
		current_node = next_node;
		next_node = next_node->next;
	}
	//update last and current node
	current_node->next = previous_node;
	List->head = current_node;
	return;
}
Data* get_item_linked_list(Linked_List *List, int index) {
	assert(List);
	if (index < 0 || index >= List->size) {
		printf("Error(get_item_linked_list): index out of range");
		return NULL;
	}
	Node *current_node = List->head;
	int i = 0;
	while (i++ < index)
		current_node = current_node->next;
	return current_node->data;
}

void swap_items_linked_list(Linked_List *List, int i, int j) {
	assert(List);

	//case 1 linked list is empty
	if (is_empty_linked_list(List)) {
		printf("Error(swap_items_linked_list): linked list is empty\n");
		return;
	}
	//case 2 invalid index
	if (i < 0 || i >= List->size || j < 0 || j >= List->size) {
		printf("Error(swap_items_linked_list): invalid index\n");
		return;
	}
	//case 3 i == j do nothing
	if (i == j)
		return;
	//t dimpligy solution, ensure i is smaller than j
	if (i > j) {
		int temp = i;
		i = j;
		j = temp;
	}
	//find node A(node at index i)
	Node *A_previous = NULL;
	Node *A = List->head;
	int location = 0;
	while (location < i) {
		A_previous = A;
		A = A->next;
		location++;
	}
	Node *B_previous = A_previous;
	Node *B = A;		//because B is after A u can start there instead of head
	while (location < j) {
		B_previous = B;
		B = B->next;
		location++;
	}
	//check if the two nodes are adjacent to each other
	int adj = (B_previous == A) ? True : False;
	//int adj  = (j == i+1)? True: False; the same

	//case 4 adjacent nodes
	if (adj) {
		if (A == List->head)
			List->head = B;
		else
			A_previous->next = B;
		A->next = B->next;
		B->next = A;
	}
	//case 5 non adj
	else {
		Node *temp = A->next;
		if (A == List->head)
			List->head = B;
		else
			A_previous->next = B;
		B_previous->next = A;
		A->next = B->next;
		B->next = temp;

	}

	return;
}
