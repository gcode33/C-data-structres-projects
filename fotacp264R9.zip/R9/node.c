/*
 -------------------------------------
 File:    node.c
 Project: R9
 file description
 -------------------------------------
 Author:  your name here
 ID:      your ID here
 Email:   your Laurier email here
 Version  2022-06-27
 -------------------------------------
 */
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "node.h"

Node* create_node(Data *d, Node *n) {
	assert(d);
	Node *node = (Node*) malloc(sizeof(Node));
	node->data = d;
	node->next = n;
	return node;
}
void destroy_node(Node **n) {
	assert(n && *n);
	(*n)->data = NULL;
	(*n)->next = NULL;
	free(*n);
	*n = NULL;
	return;
}
void print_node(Node *n) {
	assert(n);
	print_data(n->data);
	return;
}
Node* copy_node(Node *source) {
	assert(source);
	Node *destination = create_node(copy_data(source->data), source->next);
	return destination;
}
