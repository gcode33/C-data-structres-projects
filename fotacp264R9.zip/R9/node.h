/*
 -------------------------------------
 File:    node.H
 Project: R9
 file description
 -------------------------------------
 Author:  your name here
 ID:      your ID here
 Email:   your Laurier email here
 Version  2022-06-27
 -------------------------------------
 */

#ifndef NODE_H_
#define NODE_H_
#include "data.h"

typedef struct Linked_List_Node {
	Data *data;
	struct Linked_List_Node *next; //pointer to next node
} Node;

Node* create_node(Data *d, Node *n);
void destroy_node(Node **n);
void print_node(Node *n);
Node* copy_node(Node *source);
#endif /* NODE_H_ */
