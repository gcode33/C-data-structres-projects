/*
 -------------------------------------
 File:    A3.h
 Project: A3
 file description
 -------------------------------------
 Author:  your name here
 ID:      your ID here
 Email:   your Laurier email here
 Version  2022-05-27
 -------------------------------------
 */
#ifndef A3_H_
#define A3_H_

# define MAX_ARRAY_SIZE 10
# define RESERVED_VALUE -6732

int find_index_array(int*, const int, int);
int find_max_index(int*, const int);
short get_array_size(short*, short*);
int* find_mode(int*, const int);
void update_pointer(double*, const int, double, double**);
void find_next(int*, int*, const int, int**);

#endif /* A3_H_ */
