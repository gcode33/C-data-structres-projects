/*
 -------------------------------------
 File:    A3.c
 Project: A3
 file description
 -------------------------------------
 Author:  your name here
 ID:      your ID here
 Email:   your Laurier email here
 Version  2022-05-27
 -------------------------------------
 */

# include <stdio.h>
# include "A3.h"

int find_index_array(int *array, const int size, int value) {
	if (array == NULL) {
		printf("error(find_index_array): NULL pointer\n");
	}
	if (size <= 0) {
		printf("error(find_index_array): invalid size\n");
	}
	int i, res = -1;
	for (i = 0; i <= size; i++)
		if (array[i] == value) {

			res = array[i];
			break;
		}

	//your code here
	return res;
}

int find_max_index(int *array, const int size) {
	if (array == NULL) {
		printf("error(reverse_array): NULL pointer\n");
	}
	if (size <= 0) {
		printf("error(reverse_array): invalid size\n");
	}
	int i, *lrg = array;
	for (i = 0; i < size; i++)
		if (*lrg < array[i]) {
			*lrg = array[i];
		}
	//your code here
	return *lrg;
}

short get_array_size(short *array, short *end_ptr) {
	short size = 0;
	while (array < end_ptr) {
		size++;
		array++;
	}
	return size;
}

int* find_mode(int *array, const int size) {
	int maxV = 0, cnt = 0, maxcnt = 0, i = 0, j = 0;
	int *ptr = &maxV;
	for (i = 0; i < size; i++) {
		cnt = 0;
		for (j = 0; j < size; j++) {
			if (array[i] == array[j]) {
				cnt++;
			}
		}
		if (cnt > maxcnt) {
			maxcnt = cnt;
			maxV = array[i];
		}
	}
	//your code here
	return ptr;
}

void update_pointer(double *arr, const int size, double threshold, double **ptr) {
	if (*(ptr) == NULL || arr == NULL || size < 0) {
		printf("invalid");
		return;
	}
	int last = -1;
	for (int i = 0; i < size; i++) {
		if (arr[i] >= threshold) {
			last = i;
		}
	}
	if (last == -1) {
		return;
	} else {
		*(ptr) = &arr[last];

	}
	//your code here
	return;
}

void find_next(int *array1, int *array2, const int size, int **ptr1) {
	if (array1 == NULL && array2 == NULL) {
		printf("error(reverse_array): NULL pointer\n");
	}
	if (size <= 0) {
		printf("error(reverse_array): invalid size\n");
	}
	int i, b, *lrg = array1, *big = array2;
	for (i = 0; i < size; i++)
		if (*lrg < array1[i]) {
			*lrg = array1[i];
		}
	for (b = 0; b < size; b++)
		if (*big < array2[b]) {
			*big = array2[b];
		}

	//your code here
	return;
}

